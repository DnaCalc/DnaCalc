Option Explicit
Private trace() As String
Private used As Long
Private calls(0 To 100) As Long
Private currentStage As String
Private currentCase As String
Private observedSheet As Worksheet
Private eventSink As Object
Public editOnSave As Boolean
Private loggerReady As Boolean
Private Type DoubleBox
    value As Double
End Type
Private Type ByteBox
    value(0 To 7) As Byte
End Type


Public Sub Note(ByVal kind As String, ByVal detail As String)
    If Not loggerReady Then
        ReDim trace(0 To 200000)
        loggerReady = True
    End If
    If used > UBound(trace) Then Err.Raise 5, , "Trace capacity exceeded"
    trace(used) = currentCase & vbTab & currentStage & vbTab & kind & vbTab & detail
    used = used + 1
End Sub
Private Function Bits(ByVal x As Double) As String
    Dim d As DoubleBox, b As ByteBox, i As Long, t As String
    d.value = x
    LSet b = d
    For i = 7 To 0 Step -1
        t = t & Right$("0" & Hex$(b.value(i)), 2)
    Next
    Bits = t
End Function
Public Function Typed(ByVal x As Variant) As String
    Dim t As String
    If IsObject(x) Then
        Typed = "vt=9;type=" & TypeName(x) & ";value=<Object>"
        Exit Function
    End If
    t = "vt=" & CStr(VarType(x)) & ";type=" & TypeName(x) & ";value="
    If IsError(x) Then
        t = t & CStr(x)
    ElseIf IsEmpty(x) Then
        t = t & "<Empty>"
    ElseIf IsNull(x) Then
        t = t & "<Null>"
    ElseIf IsArray(x) Then
        t = t & "<Array>"
    Else
        t = t & Replace(Replace(CStr(x), vbTab, "<TAB>"), vbLf, "<LF>")
        If VarType(x) = vbDouble Then t = t & ";bits=" & Bits(CDbl(x))
    End If
    Typed = t
End Function
Public Sub Stage(ByVal label As String)
    currentStage = label
    Note "stage", label
End Sub
Public Sub Snap(ws As Worksheet, ByVal addresses As String)
    Dim a As Variant, r As Range, v As Variant
    For Each a In Split(addresses, ",")
        Set r = ws.Range(CStr(a))
        For Each r In r.Cells
            v = r.Value2
            Note "cell", ws.Name & "!" & r.Address(False, False) & ";" & Typed(v)
        Next
    Next
End Sub
Public Sub CountSnapshot()
    Dim i As Long
    For i = 0 To UBound(calls)
        If calls(i) > 0 Then Note "counter", CStr(i) & "=" & CStr(calls(i))
    Next
End Sub
Public Function PlainProbe(ByVal ident As Long, x As Variant) As Variant
    calls(ident) = calls(ident) + 1
    Note "entry", "PlainProbe;id=" & CStr(ident) & ";n=" & CStr(calls(ident)) & ";arg=" & Typed(x) & ";caller=" & Application.Caller.Address(External:=True)
    PlainProbe = x
    Note "exit", "PlainProbe;id=" & CStr(ident)
End Function
Public Function PeekB1() As Variant
    Dim v As Variant
    calls(1) = calls(1) + 1
    v = observedSheet.Range("B1").Value2
    Note "entry", "PeekB1;n=" & CStr(calls(1)) & ";caller=" & Application.Caller.Address(External:=True) & ";read=" & Typed(v)
    PeekB1 = v
    Note "exit", "PeekB1"
End Function
Public Function PeekSelf() As Variant
    Dim v As Variant
    v = Application.Caller.Value2
    Note "entry", "PeekSelf;read=" & Typed(v)
    PeekSelf = v
    Note "exit", "PeekSelf"
End Function
Public Function PeekTwice() As Variant
    Dim a As Variant, b As Variant, s As Variant
    a = observedSheet.Range("B1").Value2
    Note "entry", "PeekTwice;first=" & Typed(a)
    s = Application.WorksheetFunction.Sum(1)
    b = observedSheet.Range("B1").Value2
    Note "read", "PeekTwice;second=" & Typed(b) & ";sum=" & Typed(s)
    PeekTwice = b
    Note "exit", "PeekTwice"
End Function
Public Sub Profile()
    Note "profile", "version=" & Application.Version & ";build=" & Application.Build & ";calculationVersion=" & CStr(Application.CalculationVersion) & ";os=" & Application.OperatingSystem
    Note "settings", "mode=" & CStr(Application.Calculation) & ";iteration=" & CStr(Application.Iteration) & ";maxIterations=" & CStr(Application.MaxIterations) & ";maxChange=" & CStr(Application.MaxChange) & ";calculateBeforeSave=" & CStr(Application.CalculateBeforeSave) & ";events=" & CStr(Application.EnableEvents) & ";precisionAsDisplayed=" & CStr(ThisWorkbook.PrecisionAsDisplayed) & ";date1904=" & CStr(ThisWorkbook.Date1904) & ";mtc=" & CStr(Application.MultiThreadedCalculation.Enabled) & ";threads=" & CStr(Application.MultiThreadedCalculation.ThreadCount) & ";automationSecurity=" & CStr(Application.AutomationSecurity)
    Note "force-full-setting", CStr(ThisWorkbook.ForceFullCalculation)
    Dim a As Object
    For Each a In Application.AddIns
        Note "addin", a.Name & ";installed=" & CStr(a.Installed)
    Next
    On Error GoTo ComAddInsUnavailable
    For Each a In Application.COMAddIns
        Note "com-addin", a.progID & ";connected=" & CStr(a.Connect)
    Next
    Exit Sub
ComAddInsUnavailable:
    Note "profile-unavailable", "COMAddIns;error=" & CStr(Err.Number) & ";" & Err.Description
    Err.Clear
End Sub
Public Sub SpillInfo(ws As Worksheet, ByVal atCell As String)
    On Error GoTo NoSpill
    Dim r As Range, flag As Variant
    Set r = ws.Range(atCell)
    flag = r.HasSpill
    Note "spill-flag", atCell & ";" & Typed(flag)
    If IsNull(flag) Then Exit Sub
    If Not CBool(flag) Then Exit Sub
    Note "spill", atCell & ";hasSpill=True;range=" & r.SpillingToRange.Address
    Exit Sub
NoSpill:
    Note "spill", atCell & ";error=" & CStr(Err.Number) & ";" & Err.Description
    Err.Clear
End Sub
Public Function RunCase(ByVal ident As String, ByVal output As String) As String
    On Error GoTo Failed
    currentCase = ident
    ReDim trace(0 To 200000)
    loggerReady = True
    used = 0
    '__START_EVENT_SINK__
    If Not eventSink Is Nothing Then Set eventSink.XL = Application
    Application.Calculation = xlCalculationManual
    Application.CalculateBeforeSave = False
    Set observedSheet = ThisWorkbook.Worksheets(1)
    observedSheet.Name = "S"
    Stage "profile"
    Profile
    ProbeCase ident, output
    Stage "artifact-save"
    ThisWorkbook.SaveAs output, xlOpenXMLWorkbookMacroEnabled
    CountSnapshot
    Note "artifact", output
    GoTo Finished
Failed:
    Note "fault", CStr(Err.Number) & ";" & Err.Description
Finished:
    If used = 0 Then
        RunCase = "no observations"
    Else
        Dim resultLines() As String, k As Long
        ReDim resultLines(0 To used - 1)
        For k = 0 To used - 1
            resultLines(k) = trace(k)
        Next
        RunCase = Join(resultLines, vbLf)
    End If
End Function
Public Function ReadAfterOpen() As String
    currentCase = "reopened"
    Set observedSheet = ThisWorkbook.Worksheets(1)
    Stage "after-open"
    Snap observedSheet, "A1:C5,E1,E3:E8,G1:H3"
    Profile
    CountSnapshot
    Dim resultLines() As String, k As Long
    ReDim resultLines(0 To used - 1)
    For k = 0 To used - 1
        resultLines(k) = trace(k)
    Next
    ReadAfterOpen = Join(resultLines, vbLf)
End Function
Public Function RunProbe() As String
    On Error GoTo Failed
    If "0" = "1" Then
        RunProbe = "direct-command supervisor ready"
        Exit Function
    End If
    Dim i As Long, ident As Variant, wb As Workbook, component As Object, src As String, result As String, all As String, output As String, n As Long
    Application.Calculation = xlCalculationManual
    Application.CalculateBeforeSave = False
    Application.EnableEvents = True
    src = ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.Lines(1, ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.CountOfLines)
    For i = 1 To 1
        For Each ident In Split(SelectedCaseIds(), "|")
            Set wb = Application.Workbooks.Add(xlWBATWorksheet)
            wb.VBProject.VBComponents("ThisWorkbook").CodeModule.AddFromString EventSource()
            Set component = wb.VBProject.VBComponents.Add(2)
            component.Name = "ProbeEvents"
            component.CodeModule.AddFromString "Public WithEvents XL As Application" & vbCrLf & "Private Sub XL_AfterCalculate()" & vbCrLf & "OracleProbe.Note ""event"", ""AfterCalculate""" & vbCrLf & "End Sub"
            Set component = wb.VBProject.VBComponents.Add(1)
            component.Name = "OracleProbe"
            component.CodeModule.AddFromString Replace(src, "'__START_EVENT_SINK__", "Set eventSink = New ProbeEvents")
            output = "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P09\reopen-" & CStr(ident) & "-" & Format$(i, "00") & ".xlsm"
            result = Application.Run("'" & wb.Name & "'!OracleProbe.RunCase", CStr(ident) & "/" & CStr(i), output)
            all = all & result & vbLf
            wb.Close False
            Set wb = Nothing
        Next
    Next
    RunProbe = all
    Exit Function
Failed:
    RunProbe = all & vbLf & "driver-fault:" & CStr(Err.Number) & ":" & Err.Description
End Function
Public Function CreateOneCase(ByVal ident As String, ByVal output As String) As String
    Dim wb As Workbook, component As Object, src As String, ignored As String
    src = ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.Lines(1, ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.CountOfLines)
    Set wb = Application.Workbooks.Add(xlWBATWorksheet)
    wb.VBProject.VBComponents("ThisWorkbook").CodeModule.AddFromString EventSource()
    Set component = wb.VBProject.VBComponents.Add(2)
    component.Name = "ProbeEvents"
    component.CodeModule.AddFromString "Public WithEvents XL As Application" & vbCrLf & "Private Sub XL_AfterCalculate()" & vbCrLf & "OracleProbe.Note ""event"", ""AfterCalculate""" & vbCrLf & "End Sub"
    Set component = wb.VBProject.VBComponents.Add(1)
    component.Name = "OracleProbe"
    component.CodeModule.AddFromString Replace(src, "'__START_EVENT_SINK__", "Set eventSink = New ProbeEvents")
    ignored = Application.Run("'" & wb.Name & "'!OracleProbe.RunCase", ident, output)
    CreateOneCase = wb.Name & vbLf & ignored
End Function
Private Function SelectedCaseIds() As String
    SelectedCaseIds = ""
    SelectedCaseIds = SelectedCaseIds & "manual~cse-01.xlsm|auto~cse-01.xlsm|manual~cse-02.xlsm|auto~cse-02.xlsm|manual~cse-03.xlsm|auto~cse-03.xlsm|manual~cse-04.xlsm|auto~cse-04.xlsm|manual~cse-05.xlsm|auto~cse-05.xlsm|manual~cse-06.xlsm|auto~cse-06.xlsm|manual~cse-07.xlsm|auto~cse-07.xlsm|manual~cse-08.xlsm|auto~cse-08.xlsm|manual~cse-0"
    SelectedCaseIds = SelectedCaseIds & "9.xlsm|auto~cse-09.xlsm|manual~cse-10.xlsm|auto~cse-10.xlsm|manual~explicit-at-01.xlsm|auto~explicit-at-01.xlsm|manual~explicit-at-02.xlsm|auto~explicit-at-02.xlsm|manual~explicit-at-03.xlsm|auto~explicit-at-03.xlsm|manual~explicit-at-04.xlsm|auto~explicit-at-04.xlsm|manual~explicit-at-05.xlsm|auto~"
    SelectedCaseIds = SelectedCaseIds & "explicit-at-05.xlsm|manual~explicit-at-06.xlsm|auto~explicit-at-06.xlsm|manual~explicit-at-07.xlsm|auto~explicit-at-07.xlsm|manual~explicit-at-08.xlsm|auto~explicit-at-08.xlsm|manual~explicit-at-09.xlsm|auto~explicit-at-09.xlsm|manual~explicit-at-10.xlsm|auto~explicit-at-10.xlsm|manual~fill-formula-"
    SelectedCaseIds = SelectedCaseIds & "01.xlsm|auto~fill-formula-01.xlsm|manual~fill-formula-02.xlsm|auto~fill-formula-02.xlsm|manual~fill-formula-03.xlsm|auto~fill-formula-03.xlsm|manual~fill-formula-04.xlsm|auto~fill-formula-04.xlsm|manual~fill-formula-05.xlsm|auto~fill-formula-05.xlsm|manual~fill-formula-06.xlsm|auto~fill-formula-06.x"
    SelectedCaseIds = SelectedCaseIds & "lsm|manual~fill-formula-07.xlsm|auto~fill-formula-07.xlsm|manual~fill-formula-08.xlsm|auto~fill-formula-08.xlsm|manual~fill-formula-09.xlsm|auto~fill-formula-09.xlsm|manual~fill-formula-10.xlsm|auto~fill-formula-10.xlsm|manual~fill-formula2-01.xlsm|auto~fill-formula2-01.xlsm|manual~fill-formula2-02."
    SelectedCaseIds = SelectedCaseIds & "xlsm|auto~fill-formula2-02.xlsm|manual~fill-formula2-03.xlsm|auto~fill-formula2-03.xlsm|manual~fill-formula2-04.xlsm|auto~fill-formula2-04.xlsm|manual~fill-formula2-05.xlsm|auto~fill-formula2-05.xlsm|manual~fill-formula2-06.xlsm|auto~fill-formula2-06.xlsm|manual~fill-formula2-07.xlsm|auto~fill-formu"
    SelectedCaseIds = SelectedCaseIds & "la2-07.xlsm|manual~fill-formula2-08.xlsm|auto~fill-formula2-08.xlsm|manual~fill-formula2-09.xlsm|auto~fill-formula2-09.xlsm|manual~fill-formula2-10.xlsm|auto~fill-formula2-10.xlsm|manual~formula-01.xlsm|auto~formula-01.xlsm|manual~formula-02.xlsm|auto~formula-02.xlsm|manual~formula-03.xlsm|auto~form"
    SelectedCaseIds = SelectedCaseIds & "ula-03.xlsm|manual~formula-04.xlsm|auto~formula-04.xlsm|manual~formula-05.xlsm|auto~formula-05.xlsm|manual~formula-06.xlsm|auto~formula-06.xlsm|manual~formula-07.xlsm|auto~formula-07.xlsm|manual~formula-08.xlsm|auto~formula-08.xlsm|manual~formula-09.xlsm|auto~formula-09.xlsm|manual~formula-10.xlsm|a"
    SelectedCaseIds = SelectedCaseIds & "uto~formula-10.xlsm|manual~formula2-01.xlsm|auto~formula2-01.xlsm|manual~formula2-02.xlsm|auto~formula2-02.xlsm|manual~formula2-03.xlsm|auto~formula2-03.xlsm|manual~formula2-04.xlsm|auto~formula2-04.xlsm|manual~formula2-05.xlsm|auto~formula2-05.xlsm|manual~formula2-06.xlsm|auto~formula2-06.xlsm|manu"
    SelectedCaseIds = SelectedCaseIds & "al~formula2-07.xlsm|auto~formula2-07.xlsm|manual~formula2-08.xlsm|auto~formula2-08.xlsm|manual~formula2-09.xlsm|auto~formula2-09.xlsm|manual~formula2-10.xlsm|auto~formula2-10.xlsm|manual~paste-formula-01.xlsm|auto~paste-formula-01.xlsm|manual~paste-formula-02.xlsm|auto~paste-formula-02.xlsm|manual~p"
    SelectedCaseIds = SelectedCaseIds & "aste-formula-03.xlsm|auto~paste-formula-03.xlsm|manual~paste-formula-04.xlsm|auto~paste-formula-04.xlsm|manual~paste-formula-05.xlsm|auto~paste-formula-05.xlsm|manual~paste-formula-06.xlsm|auto~paste-formula-06.xlsm|manual~paste-formula-07.xlsm|auto~paste-formula-07.xlsm|manual~paste-formula-08.xlsm"
    SelectedCaseIds = SelectedCaseIds & "|auto~paste-formula-08.xlsm|manual~paste-formula-09.xlsm|auto~paste-formula-09.xlsm|manual~paste-formula-10.xlsm|auto~paste-formula-10.xlsm|manual~paste-formula2-01.xlsm|auto~paste-formula2-01.xlsm|manual~paste-formula2-02.xlsm|auto~paste-formula2-02.xlsm|manual~paste-formula2-03.xlsm|auto~paste-for"
    SelectedCaseIds = SelectedCaseIds & "mula2-03.xlsm|manual~paste-formula2-04.xlsm|auto~paste-formula2-04.xlsm|manual~paste-formula2-05.xlsm|auto~paste-formula2-05.xlsm|manual~paste-formula2-06.xlsm|auto~paste-formula2-06.xlsm|manual~paste-formula2-07.xlsm|auto~paste-formula2-07.xlsm|manual~paste-formula2-08.xlsm|auto~paste-formula2-08.x"
    SelectedCaseIds = SelectedCaseIds & "lsm|manual~paste-formula2-09.xlsm|auto~paste-formula2-09.xlsm|manual~paste-formula2-10.xlsm|auto~paste-formula2-10.xlsm|manual~r1c1-01.xlsm|auto~r1c1-01.xlsm|manual~r1c1-02.xlsm|auto~r1c1-02.xlsm|manual~r1c1-03.xlsm|auto~r1c1-03.xlsm|manual~r1c1-04.xlsm|auto~r1c1-04.xlsm|manual~r1c1-05.xlsm|auto~r1c"
    SelectedCaseIds = SelectedCaseIds & "1-05.xlsm|manual~r1c1-06.xlsm|auto~r1c1-06.xlsm|manual~r1c1-07.xlsm|auto~r1c1-07.xlsm|manual~r1c1-08.xlsm|auto~r1c1-08.xlsm|manual~r1c1-09.xlsm|auto~r1c1-09.xlsm|manual~r1c1-10.xlsm|auto~r1c1-10.xlsm|manual~r1c1-formula2-01.xlsm|auto~r1c1-formula2-01.xlsm|manual~r1c1-formula2-02.xlsm|auto~r1c1-formu"
    SelectedCaseIds = SelectedCaseIds & "la2-02.xlsm|manual~r1c1-formula2-03.xlsm|auto~r1c1-formula2-03.xlsm|manual~r1c1-formula2-04.xlsm|auto~r1c1-formula2-04.xlsm|manual~r1c1-formula2-05.xlsm|auto~r1c1-formula2-05.xlsm|manual~r1c1-formula2-06.xlsm|auto~r1c1-formula2-06.xlsm|manual~r1c1-formula2-07.xlsm|auto~r1c1-formula2-07.xlsm|manual~r"
    SelectedCaseIds = SelectedCaseIds & "1c1-formula2-08.xlsm|auto~r1c1-formula2-08.xlsm|manual~r1c1-formula2-09.xlsm|auto~r1c1-formula2-09.xlsm|manual~r1c1-formula2-10.xlsm|auto~r1c1-formula2-10.xlsm"
    If Len(SelectedCaseIds) = 0 Then SelectedCaseIds = CaseIds()
End Function
Private Function EventSource() As String
    EventSource = "Option Explicit" & vbCrLf & _
        "Private Sub Workbook_SheetCalculate(ByVal Sh As Object)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""SheetCalculate;sheet="" & Sh.Name" & vbCrLf & _
        "End Sub" & vbCrLf & _
        "Private Sub Workbook_BeforeSave(ByVal SaveAsUI As Boolean, Cancel As Boolean)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""BeforeSave;saveAsUI="" & CStr(SaveAsUI)" & vbCrLf & _
        "If OracleProbe.editOnSave Then" & vbCrLf & _
        "OracleProbe.editOnSave = False" & vbCrLf & _
        "Me.Worksheets(""S"").Range(""A1"").Value2 = 7" & vbCrLf & _
        "OracleProbe.Note ""event"", ""BeforeSave-edited-A1=7""" & vbCrLf & _
        "End If" & vbCrLf & _
        "End Sub" & vbCrLf & _
        "Private Sub Workbook_AfterSave(ByVal Success As Boolean)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""AfterSave;success="" & CStr(Success)" & vbCrLf & _
        "End Sub"
End Function

Private Function CaseIds() As String
    CaseIds = ""
End Function
Private Sub ProbeCase(ByVal ident As String, ByVal output As String)
    Dim p As Variant, wb As Workbook, ws As Worksheet, text As String, line As Variant, r As Range
    p = Split(Split(ident, "/")(0), "~")
    Stage "before-open"
    Application.EnableEvents = True
    If CStr(p(0)) = "auto" Then Application.Calculation = xlCalculationAutomatic Else Application.Calculation = xlCalculationManual
    Note "open-context", "after-controller;mode=" & CStr(Application.Calculation) & ";source=" & CStr(p(1))
    Stage "tested-open"
    Set wb = Application.Workbooks.Open("C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P09\" & CStr(p(1)), UpdateLinks:=0, ReadOnly:=True)
    Note "mode-after-open", CStr(Application.Calculation)
    For Each ws In wb.Worksheets
        Note "opened-sheet-settings", ws.Name & ";enabled=" & CStr(ws.EnableCalculation)
        Snap ws, "A1:C5,E1,E3:E8,G1:H3"
        For Each r In ws.Range("B2:B5")
            Note "opened-formula-form", ws.Name & "!" & r.Address & ";Formula=" & CStr(r.Formula) & ";Formula2=" & CStr(r.Formula2) & ";R1C1=" & CStr(r.FormulaR1C1) & ";Formula2R1C1=" & CStr(r.Formula2R1C1)
            Note "opened-array-flags", ws.Name & "!" & r.Address & ";hasArray=" & Typed(r.HasArray) & ";hasSpill=" & Typed(r.HasSpill) & ";savedAsArray=" & Typed(r.SavedAsArray)
        Next
    Next
    text = Application.Run("'" & wb.Name & "'!OracleProbe.ReadAfterOpen")
    For Each line In Split(text, vbLf)
        Note "opened-workbook-trace", CStr(line)
    Next
    wb.Close False
    Application.Calculation = xlCalculationManual
End Sub

