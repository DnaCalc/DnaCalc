Option Explicit
Private trace() As String
Private used As Long
Private calls(0 To 100) As Long
Private currentStage As String
Private currentCase As String
Private observedSheet As Worksheet
Private Type DoubleBox
    value As Double
End Type
Private Type ByteBox
    value(0 To 7) As Byte
End Type

Public Sub Note(ByVal kind As String, ByVal detail As String)
    If used > UBound(trace) Then Err.Raise 5, , "Trace capacity exceeded"
    trace(used) = currentCase & vbTab & currentStage & vbTab & kind & vbTab & detail
    used = used + 1
End Sub
Private Function Bits(ByVal x As Double) As String
    Dim d As DoubleBox, b As ByteBox, i As Long, t As String
    d.value = x
    LSet b = d
    For i = 7 To 0 Step -1
        t = t & Right$("0" & Hex$(b.value(i)), 2)
    Next
    Bits = t
End Function
Public Function Typed(ByVal x As Variant) As String
    Dim t As String
    t = "vt=" & CStr(VarType(x)) & ";type=" & TypeName(x) & ";value="
    If IsError(x) Then
        t = t & CStr(x)
    ElseIf IsEmpty(x) Then
        t = t & "<Empty>"
    ElseIf IsNull(x) Then
        t = t & "<Null>"
    ElseIf IsArray(x) Then
        t = t & "<Array>"
    Else
        t = t & Replace(Replace(CStr(x), vbTab, "<TAB>"), vbLf, "<LF>")
        If VarType(x) = vbDouble Then t = t & ";bits=" & Bits(CDbl(x))
    End If
    Typed = t
End Function
Public Sub Stage(ByVal label As String)
    currentStage = label
    Note "stage", label
End Sub
Public Sub Snap(ws As Worksheet, ByVal addresses As String)
    Dim a As Variant, r As Range, v As Variant
    For Each a In Split(addresses, ",")
        Set r = ws.Range(CStr(a))
        For Each r In r.Cells
            v = r.Value2
            Note "cell", ws.Name & "!" & r.Address(False, False) & ";" & Typed(v)
        Next
    Next
End Sub
Public Sub CountSnapshot()
    Dim i As Long
    For i = 0 To UBound(calls)
        If calls(i) > 0 Then Note "counter", CStr(i) & "=" & CStr(calls(i))
    Next
End Sub
Public Function PlainProbe(ByVal ident As Long, x As Variant) As Variant
    calls(ident) = calls(ident) + 1
    Note "entry", "PlainProbe;id=" & CStr(ident) & ";n=" & CStr(calls(ident)) & ";arg=" & Typed(x) & ";caller=" & Application.Caller.Address(External:=True)
    PlainProbe = x
    Note "exit", "PlainProbe;id=" & CStr(ident)
End Function
Public Function PeekB1() As Variant
    Dim v As Variant
    calls(1) = calls(1) + 1
    v = observedSheet.Range("B1").Value2
    Note "entry", "PeekB1;n=" & CStr(calls(1)) & ";caller=" & Application.Caller.Address(External:=True) & ";read=" & Typed(v)
    PeekB1 = v
    Note "exit", "PeekB1"
End Function
Public Function PeekSelf() As Variant
    Dim v As Variant
    v = Application.Caller.Value2
    Note "entry", "PeekSelf;read=" & Typed(v)
    PeekSelf = v
    Note "exit", "PeekSelf"
End Function
Public Function PeekTwice() As Variant
    Dim a As Variant, b As Variant, s As Variant
    a = observedSheet.Range("B1").Value2
    Note "entry", "PeekTwice;first=" & Typed(a)
    s = Application.WorksheetFunction.Sum(1)
    b = observedSheet.Range("B1").Value2
    Note "read", "PeekTwice;second=" & Typed(b) & ";sum=" & Typed(s)
    PeekTwice = b
    Note "exit", "PeekTwice"
End Function
Public Sub Profile()
    Note "profile", "version=" & Application.Version & ";build=" & Application.Build & ";calculationVersion=" & CStr(Application.CalculationVersion) & ";os=" & Application.OperatingSystem
    Note "settings", "mode=" & CStr(Application.Calculation) & ";iteration=" & CStr(Application.Iteration) & ";maxIterations=" & CStr(Application.MaxIterations) & ";maxChange=" & CStr(Application.MaxChange) & ";calculateBeforeSave=" & CStr(Application.CalculateBeforeSave) & ";events=" & CStr(Application.EnableEvents) & ";precisionAsDisplayed=" & CStr(ThisWorkbook.PrecisionAsDisplayed) & ";date1904=" & CStr(ThisWorkbook.Date1904) & ";mtc=" & CStr(Application.MultiThreadedCalculation.Enabled) & ";threads=" & CStr(Application.MultiThreadedCalculation.ThreadCount) & ";automationSecurity=" & CStr(Application.AutomationSecurity)
    Dim a As Object
    For Each a In Application.AddIns
        Note "addin", a.Name & ";installed=" & CStr(a.Installed)
    Next
    For Each a In Application.COMAddIns
        Note "com-addin", a.progID & ";connected=" & CStr(a.Connect)
    Next
End Sub
Public Sub SpillInfo(ws As Worksheet, ByVal atCell As String)
    On Error GoTo NoSpill
    Dim r As Range
    Set r = ws.Range(atCell)
    Note "spill", atCell & ";hasSpill=" & CStr(r.HasSpill) & ";range=" & r.SpillingToRange.Address
    Exit Sub
NoSpill:
    Note "spill", atCell & ";error=" & CStr(Err.Number) & ";" & Err.Description
    Err.Clear
End Sub
Public Function RunCase(ByVal ident As String, ByVal output As String) As String
    On Error GoTo Failed
    currentCase = ident
    ReDim trace(0 To 200000)
    used = 0
    Application.Calculation = xlCalculationManual
    Application.CalculateBeforeSave = False
    Set observedSheet = ThisWorkbook.Worksheets(1)
    observedSheet.Name = "S"
    Stage "profile"
    Profile
    ProbeCase ident, output
    Stage "artifact-save"
    ThisWorkbook.SaveAs output, xlOpenXMLWorkbookMacroEnabled
    CountSnapshot
    Note "artifact", output
    GoTo Finished
Failed:
    Note "fault", CStr(Err.Number) & ";" & Err.Description
Finished:
    If used = 0 Then
        RunCase = "no observations"
    Else
        ReDim Preserve trace(0 To used - 1)
        RunCase = Join(trace, vbLf)
    End If
End Function
Public Function RunProbe() As String
    On Error GoTo Failed
    Dim i As Long, ident As Variant, wb As Workbook, component As Object, src As String, result As String, all As String, output As String, n As Long
    Application.Calculation = xlCalculationManual
    Application.CalculateBeforeSave = False
    Application.EnableEvents = True
    src = ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.Lines(1, ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.CountOfLines)
    For i = 1 To 1
        For Each ident In Split(CaseIds(), "|")
            Set wb = Application.Workbooks.Add(xlWBATWorksheet)
            Set component = wb.VBProject.VBComponents.Add(1)
            component.Name = "OracleProbe"
            component.CodeModule.AddFromString src
            output = "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P01\" & CStr(ident) & "-" & Format$(i, "00") & ".xlsm"
            result = Application.Run("'" & wb.Name & "'!OracleProbe.RunCase", CStr(ident) & "/" & CStr(i), output)
            all = all & result & vbLf
            wb.Close False
            Set wb = Nothing
        Next
    Next
    RunProbe = all
    Exit Function
Failed:
    RunProbe = all & vbLf & "driver-fault:" & CStr(Err.Number) & ":" & Err.Description
End Function

Private Function CaseIds() As String
    CaseIds = "cold-c1|cold-b1-c1|cold-contiguous|cold-reverse|cold-sheet|cold-app|cold-full|cold-rebuild|warm-c1|warm-b1-c1|warm-contiguous|warm-reverse|warm-sheet|warm-app|warm-full|warm-rebuild|counter-c1|counter-reverse|counter-sheet|counter-app|counter-full|counter-rebuild|self-fresh|self-held|twice"
End Function
Private Sub ProbeCase(ByVal ident As String, ByVal output As String)
    Dim ws As Worksheet, op As String, v As Variant
    Set ws = observedSheet
    op = Split(Split(ident, "/")(0), "-")(UBound(Split(Split(ident, "/")(0), "-")))
    Stage "setup-entry"
    ws.Range("A1").Value2 = 1
    If Left$(ident, 7) = "counter" Then
        ws.Range("B1").Formula2 = "=PlainProbe(31,A1)+1"
    Else
        ws.Range("B1").Formula2 = "=A1+1"
    End If
    ws.Range("C1").Formula2 = "=PeekB1()"
    Stage "seed"
    ws.Range("B1").Calculate
    ws.Range("C1").Calculate
    Snap ws, "A1,B1,C1"
    If ws.Range("B1").Value2 <> 2 Or ws.Range("C1").Value2 <> 2 Then Err.Raise 5, , "Invalid seed"
    If Left$(ident, 4) = "warm" Then
        Stage "warm-chain"
        Application.Calculate
        Application.Calculate
    End If
    Stage "dirty"
    ws.Range("A1").Value2 = 10
    Snap ws, "A1,B1,C1"
    v = Application.ExecuteExcel4Macro("S!R1C2")
    Note "xlf-read", Typed(v)
    Stage "tested-command"
    If InStr(ident, "b1-c1") > 0 Then
        ws.Range("B1").Calculate
        ws.Range("C1").Calculate
    ElseIf Left$(ident, 4) = "self" Then
        If InStr(ident, "held") > 0 Then
            ws.Range("C2").Value2 = 17
        End If
        ws.Range("C2").Formula2 = "=PeekSelf()"
        ws.Range("C2").Calculate
        ws.Range("C2").Calculate
        Snap ws, "C2"
    Else
        Select Case op
        Case "c1": ws.Range("C1").Calculate
        Case "contiguous": ws.Range("B1:C1").Calculate
        Case "reverse": ws.Range("C1,B1").Calculate
        Case "sheet": ws.Calculate
        Case "app": Application.Calculate
        Case "full": Application.CalculateFull
        Case "rebuild": Application.CalculateFullRebuild
        Case "twice"
            ws.Range("C3").Formula2 = "=PeekTwice()"
            ws.Range("C3").Calculate
            Snap ws, "C3"
        End Select
    End If
    Stage "after"
    Snap ws, "A1,B1,C1"
    CountSnapshot
End Sub

