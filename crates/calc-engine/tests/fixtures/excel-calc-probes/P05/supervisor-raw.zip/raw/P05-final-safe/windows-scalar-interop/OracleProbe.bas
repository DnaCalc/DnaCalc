Option Explicit
Private trace() As String
Private used As Long
Private calls(0 To 100) As Long
Private currentStage As String
Private currentCase As String
Private observedSheet As Worksheet
Private eventSink As Object
Public editOnSave As Boolean
Private loggerReady As Boolean
Private Type DoubleBox
    value As Double
End Type
Private Type ByteBox
    value(0 To 7) As Byte
End Type


Public Sub Note(ByVal kind As String, ByVal detail As String)
    If Not loggerReady Then
        ReDim trace(0 To 200000)
        loggerReady = True
    End If
    If used > UBound(trace) Then Err.Raise 5, , "Trace capacity exceeded"
    trace(used) = currentCase & vbTab & currentStage & vbTab & kind & vbTab & detail
    used = used + 1
End Sub
Private Function Bits(ByVal x As Double) As String
    Dim d As DoubleBox, b As ByteBox, i As Long, t As String
    d.value = x
    LSet b = d
    For i = 7 To 0 Step -1
        t = t & Right$("0" & Hex$(b.value(i)), 2)
    Next
    Bits = t
End Function
Public Function Typed(ByVal x As Variant) As String
    Dim t As String
    If IsObject(x) Then
        Typed = "vt=9;type=" & TypeName(x) & ";value=<Object>"
        Exit Function
    End If
    t = "vt=" & CStr(VarType(x)) & ";type=" & TypeName(x) & ";value="
    If IsError(x) Then
        t = t & CStr(x)
    ElseIf IsEmpty(x) Then
        t = t & "<Empty>"
    ElseIf IsNull(x) Then
        t = t & "<Null>"
    ElseIf IsArray(x) Then
        t = t & "<Array>"
    Else
        t = t & Replace(Replace(CStr(x), vbTab, "<TAB>"), vbLf, "<LF>")
        If VarType(x) = vbDouble Then t = t & ";bits=" & Bits(CDbl(x))
    End If
    Typed = t
End Function
Public Sub Stage(ByVal label As String)
    currentStage = label
    Note "stage", label
End Sub
Public Sub Snap(ws As Worksheet, ByVal addresses As String)
    Dim a As Variant, r As Range, v As Variant
    For Each a In Split(addresses, ",")
        Set r = ws.Range(CStr(a))
        For Each r In r.Cells
            v = r.Value2
            Note "cell", ws.Name & "!" & r.Address(False, False) & ";" & Typed(v)
        Next
    Next
End Sub
Public Sub CountSnapshot()
    Dim i As Long
    For i = 0 To UBound(calls)
        If calls(i) > 0 Then Note "counter", CStr(i) & "=" & CStr(calls(i))
    Next
End Sub
Public Function PlainProbe(ByVal ident As Long, x As Variant) As Variant
    calls(ident) = calls(ident) + 1
    Note "entry", "PlainProbe;id=" & CStr(ident) & ";n=" & CStr(calls(ident)) & ";arg=" & Typed(x) & ";caller=" & Application.Caller.Address(External:=True)
    PlainProbe = x
    Note "exit", "PlainProbe;id=" & CStr(ident)
End Function
Public Function PeekB1() As Variant
    Dim v As Variant
    calls(1) = calls(1) + 1
    v = observedSheet.Range("B1").Value2
    Note "entry", "PeekB1;n=" & CStr(calls(1)) & ";caller=" & Application.Caller.Address(External:=True) & ";read=" & Typed(v)
    PeekB1 = v
    Note "exit", "PeekB1"
End Function
Public Function PeekSelf() As Variant
    Dim v As Variant
    v = Application.Caller.Value2
    Note "entry", "PeekSelf;read=" & Typed(v)
    PeekSelf = v
    Note "exit", "PeekSelf"
End Function
Public Function PeekTwice() As Variant
    Dim a As Variant, b As Variant, s As Variant
    a = observedSheet.Range("B1").Value2
    Note "entry", "PeekTwice;first=" & Typed(a)
    s = Application.WorksheetFunction.Sum(1)
    b = observedSheet.Range("B1").Value2
    Note "read", "PeekTwice;second=" & Typed(b) & ";sum=" & Typed(s)
    PeekTwice = b
    Note "exit", "PeekTwice"
End Function
Public Sub Profile()
    Note "profile", "version=" & Application.Version & ";build=" & Application.Build & ";calculationVersion=" & CStr(Application.CalculationVersion) & ";os=" & Application.OperatingSystem
    Note "settings", "mode=" & CStr(Application.Calculation) & ";iteration=" & CStr(Application.Iteration) & ";maxIterations=" & CStr(Application.MaxIterations) & ";maxChange=" & CStr(Application.MaxChange) & ";calculateBeforeSave=" & CStr(Application.CalculateBeforeSave) & ";events=" & CStr(Application.EnableEvents) & ";precisionAsDisplayed=" & CStr(ThisWorkbook.PrecisionAsDisplayed) & ";date1904=" & CStr(ThisWorkbook.Date1904) & ";mtc=" & CStr(Application.MultiThreadedCalculation.Enabled) & ";threads=" & CStr(Application.MultiThreadedCalculation.ThreadCount) & ";automationSecurity=" & CStr(Application.AutomationSecurity)
    Note "force-full-setting", CStr(ThisWorkbook.ForceFullCalculation)
    Dim a As Object
    For Each a In Application.AddIns
        Note "addin", a.Name & ";installed=" & CStr(a.Installed)
    Next
    On Error GoTo ComAddInsUnavailable
    For Each a In Application.COMAddIns
        Note "com-addin", a.progID & ";connected=" & CStr(a.Connect)
    Next
    Exit Sub
ComAddInsUnavailable:
    Note "profile-unavailable", "COMAddIns;error=" & CStr(Err.Number) & ";" & Err.Description
    Err.Clear
End Sub
Public Sub SpillInfo(ws As Worksheet, ByVal atCell As String)
    On Error GoTo NoSpill
    Dim r As Range
    Set r = ws.Range(atCell)
    Note "spill", atCell & ";hasSpill=" & CStr(r.HasSpill) & ";range=" & r.SpillingToRange.Address
    Exit Sub
NoSpill:
    Note "spill", atCell & ";error=" & CStr(Err.Number) & ";" & Err.Description
    Err.Clear
End Sub
Public Function RunCase(ByVal ident As String, ByVal output As String) As String
    On Error GoTo Failed
    currentCase = ident
    ReDim trace(0 To 200000)
    loggerReady = True
    used = 0
    '__START_EVENT_SINK__
    If Not eventSink Is Nothing Then Set eventSink.XL = Application
    Application.Calculation = xlCalculationManual
    Application.CalculateBeforeSave = False
    Set observedSheet = ThisWorkbook.Worksheets(1)
    observedSheet.Name = "S"
    Stage "profile"
    Profile
    ProbeCase ident, output
    Stage "artifact-save"
    ThisWorkbook.SaveAs output, xlOpenXMLWorkbookMacroEnabled
    CountSnapshot
    Note "artifact", output
    GoTo Finished
Failed:
    Note "fault", CStr(Err.Number) & ";" & Err.Description
Finished:
    If used = 0 Then
        RunCase = "no observations"
    Else
        Dim resultLines() As String, k As Long
        ReDim resultLines(0 To used - 1)
        For k = 0 To used - 1
            resultLines(k) = trace(k)
        Next
        RunCase = Join(resultLines, vbLf)
    End If
End Function
Public Function ReadAfterOpen() As String
    currentCase = "reopened"
    Set observedSheet = ThisWorkbook.Worksheets(1)
    Stage "after-open"
    Snap observedSheet, "A1:C5,E1,E3:E8,G1:H3"
    Profile
    CountSnapshot
    Dim resultLines() As String, k As Long
    ReDim resultLines(0 To used - 1)
    For k = 0 To used - 1
        resultLines(k) = trace(k)
    Next
    ReadAfterOpen = Join(resultLines, vbLf)
End Function
Public Function RunProbe() As String
    On Error GoTo Failed
    Dim i As Long, ident As Variant, wb As Workbook, component As Object, src As String, result As String, all As String, output As String, n As Long
    Application.Calculation = xlCalculationManual
    Application.CalculateBeforeSave = False
    Application.EnableEvents = True
    src = ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.Lines(1, ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.CountOfLines)
    For i = 1 To 10
        For Each ident In Split(SelectedCaseIds(), "|")
            Set wb = Application.Workbooks.Add(xlWBATWorksheet)
            wb.VBProject.VBComponents("ThisWorkbook").CodeModule.AddFromString EventSource()
            Set component = wb.VBProject.VBComponents.Add(2)
            component.Name = "ProbeEvents"
            component.CodeModule.AddFromString "Public WithEvents XL As Application" & vbCrLf & "Private Sub XL_AfterCalculate()" & vbCrLf & "OracleProbe.Note ""event"", ""AfterCalculate""" & vbCrLf & "End Sub"
            Set component = wb.VBProject.VBComponents.Add(1)
            component.Name = "OracleProbe"
            component.CodeModule.AddFromString Replace(src, "'__START_EVENT_SINK__", "Set eventSink = New ProbeEvents")
            output = "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P05\" & CStr(ident) & "-" & Format$(i, "00") & ".xlsm"
            result = Application.Run("'" & wb.Name & "'!OracleProbe.RunCase", CStr(ident) & "/" & CStr(i), output)
            all = all & result & vbLf
            wb.Close False
            Set wb = Nothing
        Next
    Next
    RunProbe = all
    Exit Function
Failed:
    RunProbe = all & vbLf & "driver-fault:" & CStr(Err.Number) & ":" & Err.Description
End Function
Private Function SelectedCaseIds() As String
    SelectedCaseIds = ""
    If Len(SelectedCaseIds) = 0 Then SelectedCaseIds = CaseIds()
End Function
Private Function EventSource() As String
    EventSource = "Option Explicit" & vbCrLf & _
        "Private Sub Workbook_SheetCalculate(ByVal Sh As Object)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""SheetCalculate;sheet="" & Sh.Name" & vbCrLf & _
        "End Sub" & vbCrLf & _
        "Private Sub Workbook_BeforeSave(ByVal SaveAsUI As Boolean, Cancel As Boolean)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""BeforeSave;saveAsUI="" & CStr(SaveAsUI)" & vbCrLf & _
        "If OracleProbe.editOnSave Then" & vbCrLf & _
        "OracleProbe.editOnSave = False" & vbCrLf & _
        "Me.Worksheets(""S"").Range(""A1"").Value2 = 7" & vbCrLf & _
        "OracleProbe.Note ""event"", ""BeforeSave-edited-A1=7""" & vbCrLf & _
        "End If" & vbCrLf & _
        "End Sub" & vbCrLf & _
        "Private Sub Workbook_AfterSave(ByVal Success As Boolean)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""AfterSave;success="" & CStr(Success)" & vbCrLf & _
        "End Sub"
End Function

Private Function CaseIds() As String
    CaseIds = "growth-reader|growth-anchor|growth-both|growth-sheet|growth-full|growth-child|conflict-ab-cold|conflict-ba-cold|conflict-ab-warm|conflict-ba-warm|conflict-ab-rebuild|conflict-ba-rebuild|conflict-ab-single-a|conflict-ab-single-b|conflict-ab-mtc-off|conflict-ba-mtc-off|conflict-ab-dirty-reverse|literal|empty-formula|formatted-blank|table|grid-edge"
End Function
Private Sub ProbeCase(ByVal ident As String, ByVal output As String)
    Dim ws As Worksheet, p As String, anchor As Range, lo As ListObject, op As String
    Set ws = observedSheet
    p = Split(ident, "/")(0)
    Stage "setup"
    If Left$(p, 6) = "growth" Then
        ws.Range("Z1").Value2 = 1
        ws.Range("A1").Formula2 = "=SEQUENCE(Z1)"
        ws.Range("C10").Formula2 = "=A10+1"
        ws.Range("E10").Formula2 = "=PlainProbe(60,A10+1)"
        Application.CalculateFull
        Application.Calculate
        Stage "accepted-seed"
        Snap ws, "A1:A12,C10,E10"
        SpillInfo ws, "A1"
        Stage "dirty-growth"
        ws.Range("Z1").Value2 = 10
        Stage "tested-command"
        op = Mid$(p, InStrRev(p, "-") + 1)
        Select Case op
        Case "reader": ws.Range("C10,E10").Calculate
        Case "anchor": ws.Range("A1").Calculate
        Case "both": ws.Range("A1,C10,E10").Calculate
        Case "sheet": ws.Calculate
        Case "full": Application.CalculateFull
        Case "child": ws.Range("A10").Calculate
        End Select
        Stage "after-growth"
        Snap ws, "A1:A12,C10,E10"
        SpillInfo ws, "A1"
        CountSnapshot
        Stage "fill-before-shrink"
        Application.CalculateFull
        Snap ws, "A1:A12,C10,E10"
        Stage "shrink-anchor-reader"
        ws.Range("Z1").Value2 = 1
        ws.Range("A1,C10,E10").Calculate
        Snap ws, "A1:A12,C10,E10"
        SpillInfo ws, "A1"
        Stage "shrink-f9"
        Application.Calculate
        Snap ws, "A1:A12,C10,E10"
    ElseIf Left$(p, 8) = "conflict" Then
        ws.Range("Z1").Value2 = 0
        If InStr(p, "-ba-") > 0 Then
            ws.Range("B1").Formula2 = "=IF(Z1,SEQUENCE(4,3),1)"
            ws.Range("A3").Formula2 = "=IF(Z1,SEQUENCE(4,3),1)"
        Else
            ws.Range("A3").Formula2 = "=IF(Z1,SEQUENCE(4,3),1)"
            ws.Range("B1").Formula2 = "=IF(Z1,SEQUENCE(4,3),1)"
        End If
        ws.Range("F1").Formula2 = "=SUM(B3:C4)"
        Application.CalculateFull
        If InStr(p, "warm") > 0 Then Application.Calculate: Application.Calculate
        If InStr(p, "mtc-off") > 0 Then Application.MultiThreadedCalculation.Enabled = False
        Stage "accepted-seed"
        Snap ws, "A3,B1,F1"
        Stage "dirty"
        ws.Range("Z1").Value2 = 1
        If InStr(p, "dirty-reverse") > 0 Then ws.Range("B1").Dirty: ws.Range("A3").Dirty
        Stage "tested-command"
        If InStr(p, "single-a") > 0 Then
            ws.Range("A3").Calculate
        ElseIf InStr(p, "single-b") > 0 Then
            ws.Range("B1").Calculate
        ElseIf InStr(p, "rebuild") > 0 Then
            Application.CalculateFullRebuild
        Else
            Application.Calculate
        End If
        Stage "after-conflict"
        Snap ws, "A1:D6,F1"
        SpillInfo ws, "A3"
        SpillInfo ws, "B1"
        Stage "followup-full"
        Application.CalculateFull
        Snap ws, "A3,B1,F1"
        SpillInfo ws, "A3"
        SpillInfo ws, "B1"
        Application.MultiThreadedCalculation.Enabled = True
    Else
        Set anchor = ws.Range("A1")
        Select Case p
        Case "literal": ws.Range("A2").Value2 = 9
        Case "empty-formula": ws.Range("A2").Formula2 = "="""""
        Case "formatted-blank": ws.Range("A2").NumberFormat = "0.00": ws.Range("A2").Interior.Color = vbYellow
        Case "table"
            ws.Range("A1").Value2 = "Header"
            Set lo = ws.ListObjects.Add(xlSrcRange, ws.Range("A1:B4"), , xlYes)
            Set anchor = ws.Range("A2")
        Case "grid-edge": Set anchor = ws.Range("A1048576")
        End Select
        Stage "entry-and-full"
        anchor.Formula2 = "=SEQUENCE(3)"
        Application.CalculateFull
        Snap ws, anchor.Address & ",A1:B5"
        SpillInfo ws, anchor.Address
    End If
End Sub

