Option Explicit
Private trace() As String
Private used As Long
Private calls(0 To 100) As Long
Private currentStage As String
Private currentCase As String
Private observedSheet As Worksheet
Private eventSink As Object
Public editOnSave As Boolean
Private loggerReady As Boolean
Private Type DoubleBox
    value As Double
End Type
Private Type ByteBox
    value(0 To 7) As Byte
End Type

Private Declare PtrSafe Function DumpNative Lib "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P08\native-order.xll" (ByVal path As LongPtr) As Long
Private Declare PtrSafe Function ResetNative Lib "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P08\native-order.xll" () As Long
Private Declare PtrSafe Function MarkNative Lib "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P08\native-order.xll" (ByVal stageNumber As Long) As Long
Private Declare PtrSafe Function ObserveNative Lib "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P08\native-order.xll" (ByVal observedType As Long, ByVal observedValue As Double, ByVal site As Long) As Long

Public Sub Note(ByVal kind As String, ByVal detail As String)
    If Not loggerReady Then
        ReDim trace(0 To 200000)
        loggerReady = True
    End If
    If used > UBound(trace) Then Err.Raise 5, , "Trace capacity exceeded"
    trace(used) = currentCase & vbTab & currentStage & vbTab & kind & vbTab & detail
    used = used + 1
End Sub
Private Function Bits(ByVal x As Double) As String
    Dim d As DoubleBox, b As ByteBox, i As Long, t As String
    d.value = x
    LSet b = d
    For i = 7 To 0 Step -1
        t = t & Right$("0" & Hex$(b.value(i)), 2)
    Next
    Bits = t
End Function
Public Function Typed(ByVal x As Variant) As String
    Dim t As String
    If IsObject(x) Then
        Typed = "vt=9;type=" & TypeName(x) & ";value=<Object>"
        Exit Function
    End If
    t = "vt=" & CStr(VarType(x)) & ";type=" & TypeName(x) & ";value="
    If IsError(x) Then
        t = t & CStr(x)
    ElseIf IsEmpty(x) Then
        t = t & "<Empty>"
    ElseIf IsNull(x) Then
        t = t & "<Null>"
    ElseIf IsArray(x) Then
        t = t & "<Array>"
    Else
        t = t & Replace(Replace(CStr(x), vbTab, "<TAB>"), vbLf, "<LF>")
        If VarType(x) = vbDouble Then t = t & ";bits=" & Bits(CDbl(x))
    End If
    Typed = t
End Function
Public Sub Stage(ByVal label As String)
    currentStage = label
    Note "stage", label
End Sub
Public Sub Snap(ws As Worksheet, ByVal addresses As String)
    Dim a As Variant, r As Range, v As Variant
    For Each a In Split(addresses, ",")
        Set r = ws.Range(CStr(a))
        For Each r In r.Cells
            v = r.Value2
            Note "cell", ws.Name & "!" & r.Address(False, False) & ";" & Typed(v)
        Next
    Next
End Sub
Public Sub CountSnapshot()
    Dim i As Long
    For i = 0 To UBound(calls)
        If calls(i) > 0 Then Note "counter", CStr(i) & "=" & CStr(calls(i))
    Next
End Sub
Public Function PlainProbe(ByVal ident As Long, x As Variant) As Variant
    calls(ident) = calls(ident) + 1
    Note "entry", "PlainProbe;id=" & CStr(ident) & ";n=" & CStr(calls(ident)) & ";arg=" & Typed(x) & ";caller=" & Application.Caller.Address(External:=True)
    PlainProbe = x
    Note "exit", "PlainProbe;id=" & CStr(ident)
End Function
Public Function PeekB1() As Variant
    Dim v As Variant
    calls(1) = calls(1) + 1
    v = observedSheet.Range("B1").Value2
    Note "entry", "PeekB1;n=" & CStr(calls(1)) & ";caller=" & Application.Caller.Address(External:=True) & ";read=" & Typed(v)
    PeekB1 = v
    Note "exit", "PeekB1"
End Function
Public Function PeekSelf() As Variant
    Dim v As Variant
    v = Application.Caller.Value2
    Note "entry", "PeekSelf;read=" & Typed(v)
    PeekSelf = v
    Note "exit", "PeekSelf"
End Function
Public Function PeekTwice() As Variant
    Dim a As Variant, b As Variant, s As Variant
    a = observedSheet.Range("B1").Value2
    Note "entry", "PeekTwice;first=" & Typed(a)
    s = Application.WorksheetFunction.Sum(1)
    b = observedSheet.Range("B1").Value2
    Note "read", "PeekTwice;second=" & Typed(b) & ";sum=" & Typed(s)
    PeekTwice = b
    Note "exit", "PeekTwice"
End Function
Public Sub Profile()
    Note "profile", "version=" & Application.Version & ";build=" & Application.Build & ";calculationVersion=" & CStr(Application.CalculationVersion) & ";os=" & Application.OperatingSystem
    Note "settings", "mode=" & CStr(Application.Calculation) & ";iteration=" & CStr(Application.Iteration) & ";maxIterations=" & CStr(Application.MaxIterations) & ";maxChange=" & CStr(Application.MaxChange) & ";calculateBeforeSave=" & CStr(Application.CalculateBeforeSave) & ";events=" & CStr(Application.EnableEvents) & ";precisionAsDisplayed=" & CStr(ThisWorkbook.PrecisionAsDisplayed) & ";date1904=" & CStr(ThisWorkbook.Date1904) & ";mtc=" & CStr(Application.MultiThreadedCalculation.Enabled) & ";threads=" & CStr(Application.MultiThreadedCalculation.ThreadCount) & ";automationSecurity=" & CStr(Application.AutomationSecurity)
    Note "force-full-setting", CStr(ThisWorkbook.ForceFullCalculation)
    Dim a As Object
    For Each a In Application.AddIns
        Note "addin", a.Name & ";installed=" & CStr(a.Installed)
    Next
    On Error GoTo ComAddInsUnavailable
    For Each a In Application.COMAddIns
        Note "com-addin", a.progID & ";connected=" & CStr(a.Connect)
    Next
    Exit Sub
ComAddInsUnavailable:
    Note "profile-unavailable", "COMAddIns;error=" & CStr(Err.Number) & ";" & Err.Description
    Err.Clear
End Sub
Public Sub SpillInfo(ws As Worksheet, ByVal atCell As String)
    On Error GoTo NoSpill
    Dim r As Range, flag As Variant
    Set r = ws.Range(atCell)
    flag = r.HasSpill
    Note "spill-flag", atCell & ";" & Typed(flag)
    If IsNull(flag) Then Exit Sub
    If Not CBool(flag) Then Exit Sub
    Note "spill", atCell & ";hasSpill=True;range=" & r.SpillingToRange.Address
    Exit Sub
NoSpill:
    Note "spill", atCell & ";error=" & CStr(Err.Number) & ";" & Err.Description
    Err.Clear
End Sub
Public Function RunCase(ByVal ident As String, ByVal output As String) As String
    On Error GoTo Failed
    currentCase = ident
    ReDim trace(0 To 200000)
    loggerReady = True
    used = 0
    '__START_EVENT_SINK__
    If Not eventSink Is Nothing Then Set eventSink.XL = Application
    Application.Calculation = xlCalculationManual
    Application.CalculateBeforeSave = False
    Set observedSheet = ThisWorkbook.Worksheets(1)
    observedSheet.Name = "S"
    Stage "profile"
    Profile
    ProbeCase ident, output
    Stage "artifact-save"
    ThisWorkbook.SaveAs output, xlOpenXMLWorkbookMacroEnabled
    CountSnapshot
    Note "artifact", output
    GoTo Finished
Failed:
    Note "fault", CStr(Err.Number) & ";" & Err.Description
Finished:
    If used = 0 Then
        RunCase = "no observations"
    Else
        Dim resultLines() As String, k As Long
        ReDim resultLines(0 To used - 1)
        For k = 0 To used - 1
            resultLines(k) = trace(k)
        Next
        RunCase = Join(resultLines, vbLf)
    End If
End Function
Public Function ReadAfterOpen() As String
    currentCase = "reopened"
    Set observedSheet = ThisWorkbook.Worksheets(1)
    Stage "after-open"
    Snap observedSheet, "A1:C5,E1,E3:E8,G1:H3"
    Profile
    CountSnapshot
    Dim resultLines() As String, k As Long
    ReDim resultLines(0 To used - 1)
    For k = 0 To used - 1
        resultLines(k) = trace(k)
    Next
    ReadAfterOpen = Join(resultLines, vbLf)
End Function
Public Function RunProbe() As String
    On Error GoTo Failed
    If "0" = "1" Then
        RunProbe = "direct-command supervisor ready"
        Exit Function
    End If
    Dim i As Long, ident As Variant, wb As Workbook, component As Object, src As String, result As String, all As String, output As String, n As Long
    Application.Calculation = xlCalculationManual
    Application.CalculateBeforeSave = False
    Application.EnableEvents = True
    src = ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.Lines(1, ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.CountOfLines)
    For i = 1 To 1
        For Each ident In Split(SelectedCaseIds(), "|")
            Set wb = Application.Workbooks.Add(xlWBATWorksheet)
            wb.VBProject.VBComponents("ThisWorkbook").CodeModule.AddFromString EventSource()
            Set component = wb.VBProject.VBComponents.Add(2)
            component.Name = "ProbeEvents"
            component.CodeModule.AddFromString "Public WithEvents XL As Application" & vbCrLf & "Private Sub XL_AfterCalculate()" & vbCrLf & "OracleProbe.Note ""event"", ""AfterCalculate""" & vbCrLf & "End Sub"
            Set component = wb.VBProject.VBComponents.Add(1)
            component.Name = "OracleProbe"
            component.CodeModule.AddFromString Replace(src, "'__START_EVENT_SINK__", "Set eventSink = New ProbeEvents")
            output = "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P08\trial-" & CStr(ident) & "-" & Format$(i, "00") & ".xlsm"
            result = Application.Run("'" & wb.Name & "'!OracleProbe.RunCase", CStr(ident) & "/" & CStr(i), output)
            all = all & result & vbLf
            wb.Close False
            Set wb = Nothing
        Next
    Next
    RunProbe = all
    Exit Function
Failed:
    RunProbe = all & vbLf & "driver-fault:" & CStr(Err.Number) & ":" & Err.Description
End Function
Public Function CreateOneCase(ByVal ident As String, ByVal output As String) As String
    Dim wb As Workbook, component As Object, src As String, ignored As String
    src = ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.Lines(1, ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.CountOfLines)
    Set wb = Application.Workbooks.Add(xlWBATWorksheet)
    wb.VBProject.VBComponents("ThisWorkbook").CodeModule.AddFromString EventSource()
    Set component = wb.VBProject.VBComponents.Add(2)
    component.Name = "ProbeEvents"
    component.CodeModule.AddFromString "Public WithEvents XL As Application" & vbCrLf & "Private Sub XL_AfterCalculate()" & vbCrLf & "OracleProbe.Note ""event"", ""AfterCalculate""" & vbCrLf & "End Sub"
    Set component = wb.VBProject.VBComponents.Add(1)
    component.Name = "OracleProbe"
    component.CodeModule.AddFromString Replace(src, "'__START_EVENT_SINK__", "Set eventSink = New ProbeEvents")
    ignored = Application.Run("'" & wb.Name & "'!OracleProbe.RunCase", ident, output)
    CreateOneCase = wb.Name & vbLf & ignored
End Function
Private Function SelectedCaseIds() As String
    SelectedCaseIds = ""
    If Len(SelectedCaseIds) = 0 Then SelectedCaseIds = CaseIds()
End Function
Private Function EventSource() As String
    EventSource = "Option Explicit" & vbCrLf & _
        "Private Sub Workbook_SheetCalculate(ByVal Sh As Object)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""SheetCalculate;sheet="" & Sh.Name" & vbCrLf & _
        "End Sub" & vbCrLf & _
        "Private Sub Workbook_BeforeSave(ByVal SaveAsUI As Boolean, Cancel As Boolean)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""BeforeSave;saveAsUI="" & CStr(SaveAsUI)" & vbCrLf & _
        "If OracleProbe.editOnSave Then" & vbCrLf & _
        "OracleProbe.editOnSave = False" & vbCrLf & _
        "Me.Worksheets(""S"").Range(""A1"").Value2 = 7" & vbCrLf & _
        "OracleProbe.Note ""event"", ""BeforeSave-edited-A1=7""" & vbCrLf & _
        "End If" & vbCrLf & _
        "End Sub" & vbCrLf & _
        "Private Sub Workbook_AfterSave(ByVal Success As Boolean)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""AfterSave;success="" & CStr(Success)" & vbCrLf & _
        "End Sub"
End Function

Private Function CaseIds() As String
    Dim entry As Variant, chain As Variant, mtc As Variant, t As String
    For Each entry In Array("producer", "observer")
        For Each chain In Array("cold", "warm", "rebuild")
            For Each mtc In Array("on", "off")
                If Len(t) > 0 Then t = t & "|"
                t = t & CStr(entry) & "-" & CStr(chain) & "-" & CStr(mtc)
            Next
        Next
    Next
    CaseIds = t & "|producer-cold-other-active|observer-cold-other-active|producer-cold-scroll|observer-cold-scroll|producer-cold-lower-chain|observer-cold-lower-chain|producer-cold-one-thread|observer-cold-one-thread"
End Function
Public Function PeekSeveral() As Variant
    Dim a As Variant, b As Variant, c As Variant, n As Long
    a = observedSheet.Range("B1").Value2
    b = observedSheet.Range("D1").Value2
    c = observedSheet.Range("H1").Value2
    n = ObserveNative(VarType(a), CDbl(a), 1)
    n = ObserveNative(VarType(b), CDbl(b), 2)
    n = ObserveNative(VarType(c), CDbl(c), 3)
    Note "entry", "PeekSeveral;B1=" & Typed(a) & ";D1=" & Typed(b) & ";H1=" & Typed(c)
    PeekSeveral = CStr(a) & ":" & CStr(b) & ":" & CStr(c)
    Note "exit", "PeekSeveral"
End Function
Private Sub EnterObservers(ws As Worksheet)
    ws.Range("C1").Formula2 = "=PeekB1()"
    ws.Range("F1").Formula2 = "=PeekSeveral()"
End Sub
Private Sub EnterProducers(ws As Worksheet, ByVal firstRow As Long)
    ws.Cells(firstRow, 11).Value2 = 1
    ws.Range(ws.Cells(firstRow + 1, 11), ws.Cells(firstRow + 999, 11)).FormulaR1C1 = "=R[-1]C+1"
    ws.Cells(firstRow, 12).Value2 = 100
    ws.Range(ws.Cells(firstRow + 1, 12), ws.Cells(firstRow + 999, 12)).FormulaR1C1 = "=R[-1]C+1"
    ws.Range("B1").Formula2 = "=K" & CStr(firstRow + 999) & "+1"
    ws.Range("D1").Formula2 = "=L" & CStr(firstRow + 999) & "+1"
    ws.Range("H1").Formula2 = "=XPure(K" & CStr(firstRow + 999) & "+1)"
End Sub
Private Sub ProbeCase(ByVal ident As String, ByVal output As String)
    Dim ws As Worksheet, other As Worksheet, p As String, firstRow As Long, n As Long, path As String, oldThreadMode As Long
    Set ws = observedSheet
    p = Split(ident, "/")(0)
    firstRow = 1
    If InStr(p, "lower-chain") > 0 Then firstRow = 2000
    Stage "setup-entry-history"
    Note "register-xll", CStr(Application.RegisterXLL("C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P08\native-order.xll"))
    n = ResetNative()
    n = MarkNative(1)
    If Left$(p, 8) = "observer" Then EnterObservers ws
    EnterProducers ws, firstRow
    If Left$(p, 8) <> "observer" Then EnterObservers ws
    Application.CalculateFull
    ws.Range("B1,D1,H1").Calculate
    ws.Range("C1,F1").Calculate
    Stage "accepted-seed"
    Snap ws, "B1:D1,F1,H1"
    If ws.Range("B1").Value2 <> 1001 Or ws.Range("C1").Value2 <> 1001 Then Err.Raise 5, , "Invalid observer seed"
    If InStr(p, "warm") > 0 Then Application.Calculate: Application.Calculate
    If Right$(p, 3) = "off" Then Application.MultiThreadedCalculation.Enabled = False Else Application.MultiThreadedCalculation.Enabled = True
    If InStr(p, "one-thread") > 0 Then
        oldThreadMode = Application.MultiThreadedCalculation.ThreadMode
        Application.MultiThreadedCalculation.ThreadMode = xlThreadModeManual
        On Error Resume Next
        CallByName Application.MultiThreadedCalculation, "ThreadCount", VbLet, 1
        Note "thread-count-set", "error=" & CStr(Err.Number) & ";" & Err.Description & ";actual=" & CStr(Application.MultiThreadedCalculation.ThreadCount)
        Err.Clear
        On Error GoTo 0
        If Application.MultiThreadedCalculation.ThreadCount <> 1 Then
            Application.MultiThreadedCalculation.ThreadMode = oldThreadMode
            Note "unrunnable", "One-thread MTC count cannot be set through this COM property; no UI/registry setting changed"
            Exit Sub
        End If
    End If
    If InStr(p, "other-active") > 0 Then
        Set other = ThisWorkbook.Worksheets.Add(After:=ws)
        other.Name = "ActiveOther"
        other.Activate
    Else
        ws.Activate
    End If
    If InStr(p, "scroll") > 0 Then
        ws.Range("Z3000").Select
        ActiveWindow.ScrollRow = 2990
    Else
        ActiveSheet.Range("A1").Select
        ActiveWindow.ScrollRow = 1
    End If
    Stage "dirty"
    ws.Cells(firstRow, 11).Value2 = 10
    ws.Cells(firstRow, 12).Value2 = 200
    Note "layout", "activeSheet=" & ActiveSheet.Name & ";selection=" & Selection.Address & ";scrollRow=" & CStr(ActiveWindow.ScrollRow) & ";firstChainRow=" & CStr(firstRow) & ";mtc=" & CStr(Application.MultiThreadedCalculation.Enabled)
    Stage "tested-command"
    n = MarkNative(2)
    If InStr(p, "rebuild") > 0 Then Application.CalculateFullRebuild Else Application.CalculateFull
    Stage "after"
    Snap ws, "B1:D1,F1,H1"
    CountSnapshot
    path = Replace(output, ".xlsm", "-native.tsv")
    n = DumpNative(StrPtr(path))
    Note "native-records", CStr(n)
    Application.MultiThreadedCalculation.Enabled = True
    If InStr(p, "one-thread") > 0 Then Application.MultiThreadedCalculation.ThreadMode = oldThreadMode
End Sub
