Option Explicit
Private trace() As String
Private used As Long
Private calls(0 To 100) As Long
Private currentStage As String
Private currentCase As String
Private observedSheet As Worksheet
Private eventSink As Object
Public editOnSave As Boolean
Private Type DoubleBox
    value As Double
End Type
Private Type ByteBox
    value(0 To 7) As Byte
End Type

Public Sub Note(ByVal kind As String, ByVal detail As String)
    If used > UBound(trace) Then Err.Raise 5, , "Trace capacity exceeded"
    trace(used) = currentCase & vbTab & currentStage & vbTab & kind & vbTab & detail
    used = used + 1
End Sub
Private Function Bits(ByVal x As Double) As String
    Dim d As DoubleBox, b As ByteBox, i As Long, t As String
    d.value = x
    LSet b = d
    For i = 7 To 0 Step -1
        t = t & Right$("0" & Hex$(b.value(i)), 2)
    Next
    Bits = t
End Function
Public Function Typed(ByVal x As Variant) As String
    Dim t As String
    t = "vt=" & CStr(VarType(x)) & ";type=" & TypeName(x) & ";value="
    If IsError(x) Then
        t = t & CStr(x)
    ElseIf IsEmpty(x) Then
        t = t & "<Empty>"
    ElseIf IsNull(x) Then
        t = t & "<Null>"
    ElseIf IsArray(x) Then
        t = t & "<Array>"
    Else
        t = t & Replace(Replace(CStr(x), vbTab, "<TAB>"), vbLf, "<LF>")
        If VarType(x) = vbDouble Then t = t & ";bits=" & Bits(CDbl(x))
    End If
    Typed = t
End Function
Public Sub Stage(ByVal label As String)
    currentStage = label
    Note "stage", label
End Sub
Public Sub Snap(ws As Worksheet, ByVal addresses As String)
    Dim a As Variant, r As Range, v As Variant
    For Each a In Split(addresses, ",")
        Set r = ws.Range(CStr(a))
        For Each r In r.Cells
            v = r.Value2
            Note "cell", ws.Name & "!" & r.Address(False, False) & ";" & Typed(v)
        Next
    Next
End Sub
Public Sub CountSnapshot()
    Dim i As Long
    For i = 0 To UBound(calls)
        If calls(i) > 0 Then Note "counter", CStr(i) & "=" & CStr(calls(i))
    Next
End Sub
Public Function PlainProbe(ByVal ident As Long, x As Variant) As Variant
    calls(ident) = calls(ident) + 1
    Note "entry", "PlainProbe;id=" & CStr(ident) & ";n=" & CStr(calls(ident)) & ";arg=" & Typed(x) & ";caller=" & Application.Caller.Address(External:=True)
    PlainProbe = x
    Note "exit", "PlainProbe;id=" & CStr(ident)
End Function
Public Function PeekB1() As Variant
    Dim v As Variant
    calls(1) = calls(1) + 1
    v = observedSheet.Range("B1").Value2
    Note "entry", "PeekB1;n=" & CStr(calls(1)) & ";caller=" & Application.Caller.Address(External:=True) & ";read=" & Typed(v)
    PeekB1 = v
    Note "exit", "PeekB1"
End Function
Public Function PeekSelf() As Variant
    Dim v As Variant
    v = Application.Caller.Value2
    Note "entry", "PeekSelf;read=" & Typed(v)
    PeekSelf = v
    Note "exit", "PeekSelf"
End Function
Public Function PeekTwice() As Variant
    Dim a As Variant, b As Variant, s As Variant
    a = observedSheet.Range("B1").Value2
    Note "entry", "PeekTwice;first=" & Typed(a)
    s = Application.WorksheetFunction.Sum(1)
    b = observedSheet.Range("B1").Value2
    Note "read", "PeekTwice;second=" & Typed(b) & ";sum=" & Typed(s)
    PeekTwice = b
    Note "exit", "PeekTwice"
End Function
Public Sub Profile()
    Note "profile", "version=" & Application.Version & ";build=" & Application.Build & ";calculationVersion=" & CStr(Application.CalculationVersion) & ";os=" & Application.OperatingSystem
    Note "settings", "mode=" & CStr(Application.Calculation) & ";iteration=" & CStr(Application.Iteration) & ";maxIterations=" & CStr(Application.MaxIterations) & ";maxChange=" & CStr(Application.MaxChange) & ";calculateBeforeSave=" & CStr(Application.CalculateBeforeSave) & ";events=" & CStr(Application.EnableEvents) & ";precisionAsDisplayed=" & CStr(ThisWorkbook.PrecisionAsDisplayed) & ";date1904=" & CStr(ThisWorkbook.Date1904) & ";mtc=" & CStr(Application.MultiThreadedCalculation.Enabled) & ";threads=" & CStr(Application.MultiThreadedCalculation.ThreadCount) & ";automationSecurity=" & CStr(Application.AutomationSecurity)
    Dim a As Object
    For Each a In Application.AddIns
        Note "addin", a.Name & ";installed=" & CStr(a.Installed)
    Next
    On Error GoTo ComAddInsUnavailable
    For Each a In Application.COMAddIns
        Note "com-addin", a.progID & ";connected=" & CStr(a.Connect)
    Next
    Exit Sub
ComAddInsUnavailable:
    Note "profile-unavailable", "COMAddIns;error=" & CStr(Err.Number) & ";" & Err.Description
    Err.Clear
End Sub
Public Sub SpillInfo(ws As Worksheet, ByVal atCell As String)
    On Error GoTo NoSpill
    Dim r As Range
    Set r = ws.Range(atCell)
    Note "spill", atCell & ";hasSpill=" & CStr(r.HasSpill) & ";range=" & r.SpillingToRange.Address
    Exit Sub
NoSpill:
    Note "spill", atCell & ";error=" & CStr(Err.Number) & ";" & Err.Description
    Err.Clear
End Sub
Public Function RunCase(ByVal ident As String, ByVal output As String) As String
    On Error GoTo Failed
    currentCase = ident
    ReDim trace(0 To 200000)
    used = 0
    '__START_EVENT_SINK__
    If Not eventSink Is Nothing Then Set eventSink.XL = Application
    Application.Calculation = xlCalculationManual
    Application.CalculateBeforeSave = False
    Set observedSheet = ThisWorkbook.Worksheets(1)
    observedSheet.Name = "S"
    Stage "profile"
    Profile
    ProbeCase ident, output
    Stage "artifact-save"
    ThisWorkbook.SaveAs output, xlOpenXMLWorkbookMacroEnabled
    CountSnapshot
    Note "artifact", output
    GoTo Finished
Failed:
    Note "fault", CStr(Err.Number) & ";" & Err.Description
Finished:
    If used = 0 Then
        RunCase = "no observations"
    Else
        Dim resultLines() As String, k As Long
        ReDim resultLines(0 To used - 1)
        For k = 0 To used - 1
            resultLines(k) = trace(k)
        Next
        RunCase = Join(resultLines, vbLf)
    End If
End Function
Public Function RunProbe() As String
    On Error GoTo Failed
    Dim i As Long, ident As Variant, wb As Workbook, component As Object, src As String, result As String, all As String, output As String, n As Long
    Application.Calculation = xlCalculationManual
    Application.CalculateBeforeSave = False
    Application.EnableEvents = True
    src = ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.Lines(1, ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.CountOfLines)
    For i = 1 To 1
        For Each ident In Split(CaseIds(), "|")
            Set wb = Application.Workbooks.Add(xlWBATWorksheet)
            wb.VBProject.VBComponents("ThisWorkbook").CodeModule.AddFromString EventSource()
            Set component = wb.VBProject.VBComponents.Add(2)
            component.Name = "ProbeEvents"
            component.CodeModule.AddFromString "Public WithEvents XL As Application" & vbCrLf & "Private Sub XL_AfterCalculate()" & vbCrLf & "OracleProbe.Note ""event"", ""AfterCalculate""" & vbCrLf & "End Sub"
            Set component = wb.VBProject.VBComponents.Add(1)
            component.Name = "OracleProbe"
            component.CodeModule.AddFromString Replace(src, "'__START_EVENT_SINK__", "Set eventSink = New ProbeEvents")
            output = "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P02\" & CStr(ident) & "-" & Format$(i, "00") & ".xlsm"
            result = Application.Run("'" & wb.Name & "'!OracleProbe.RunCase", CStr(ident) & "/" & CStr(i), output)
            all = all & result & vbLf
            wb.Close False
            Set wb = Nothing
        Next
    Next
    RunProbe = all
    Exit Function
Failed:
    RunProbe = all & vbLf & "driver-fault:" & CStr(Err.Number) & ":" & Err.Description
End Function
Private Function EventSource() As String
    EventSource = "Option Explicit" & vbCrLf & _
        "Private Sub Workbook_SheetCalculate(ByVal Sh As Object)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""SheetCalculate;sheet="" & Sh.Name" & vbCrLf & _
        "End Sub" & vbCrLf & _
        "Private Sub Workbook_BeforeSave(ByVal SaveAsUI As Boolean, Cancel As Boolean)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""BeforeSave;saveAsUI="" & CStr(SaveAsUI)" & vbCrLf & _
        "If OracleProbe.editOnSave Then" & vbCrLf & _
        "OracleProbe.editOnSave = False" & vbCrLf & _
        "Me.Worksheets(""S"").Range(""A1"").Value2 = 7" & vbCrLf & _
        "OracleProbe.Note ""event"", ""BeforeSave-edited-A1=7""" & vbCrLf & _
        "End If" & vbCrLf & _
        "End Sub" & vbCrLf & _
        "Private Sub Workbook_AfterSave(ByVal Success As Boolean)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""AfterSave;success="" & CStr(Success)" & vbCrLf & _
        "End Sub"
End Function

Private Function CaseIds() As String
    Dim mode As Variant, op As Variant, t As String
    For Each mode In Array("manual", "auto", "except")
        For Each op In Array("c1", "range", "sequential", "union-cb", "union-bc", "sheet", "app", "full", "rebuild", "rowmajor")
            If Len(t) > 0 Then t = t & "|"
            t = t & CStr(mode) & "-" & CStr(op)
        Next
    Next
    CaseIds = t & "|cross-sheet-c1|cross-sheet-sheet|cross-sheet-app|cross-book-c1|cross-book-sheet|cross-book-app|reverse-range|reverse-rowmajor|disabled-sheet|disabled-full|forcefull-c1|forcefull-app|group-sheet"
End Function
Private Sub ProbeCase(ByVal ident As String, ByVal output As String)
    Dim ws As Worksheet, other As Worksheet, provider As Workbook, b As Range, c As Range, p As String, op As String
    Set ws = observedSheet
    p = Split(ident, "/")(0)
    op = Mid$(p, InStrRev(p, "-") + 1)
    Stage "setup-entry"
    ws.Range("A1").Value2 = 1
    ws.Range("B1").Formula2 = "=A1*2"
    ws.Range("C1").Formula2 = "=B1+1"
    ws.Range("B3").Formula2 = "=PlainProbe(32,A1)"
    ws.Range("C3").Formula2 = "=PlainProbe(33,B3)"
    ws.Range("K1").Formula2 = "=PlainProbe(34,1)"
    ws.Range("X1").Value2 = 0
    ws.Range("Y1").Formula2 = "=X1+1"
    Set b = ws.Range("B1")
    Set c = ws.Range("C1")
    If Left$(p, 11) = "cross-sheet" Then
        Set other = ThisWorkbook.Worksheets.Add(After:=ws)
        other.Name = "Producer"
        other.Range("A1").Value2 = 1
        other.Range("B1").Formula2 = "=A1*2"
        ws.Range("B1").ClearContents
        c.Formula2 = "=Producer!B1+1"
        Set b = other.Range("B1")
    ElseIf Left$(p, 10) = "cross-book" Then
        Set provider = Application.Workbooks.Add(xlWBATWorksheet)
        Set other = provider.Worksheets(1)
        other.Range("A1").Value2 = 1
        other.Range("B1").Formula2 = "=A1*2"
        provider.SaveAs Replace(output, ".xlsm", "-provider.xlsx"), xlOpenXMLWorkbook
        ws.Range("B1").ClearContents
        c.Formula2 = "='[" & provider.Name & "]" & other.Name & "'!B1+1"
        Set b = other.Range("B1")
        ThisWorkbook.Activate
    ElseIf Left$(p, 7) = "reverse" Then
        ws.Range("A1:C1").ClearContents
        ws.Range("C1").Value2 = 1
        ws.Range("B1").Formula2 = "=C1*2"
        ws.Range("A1").Formula2 = "=B1+1"
    End If
    Stage "seed"
    Application.CalculateFullRebuild
    Application.Calculate
    Snap ws, "A1:C1,B3:C3,K1,X1:Y1"
    CountSnapshot
    If Left$(p, 4) = "auto" Then
        Stage "mode-switch-auto"
        Application.Calculation = xlCalculationAutomatic
    ElseIf Left$(p, 6) = "except" Then
        Stage "mode-switch-except"
        Application.Calculation = xlCalculationSemiautomatic
    End If
    If Left$(p, 8) = "disabled" Then ws.EnableCalculation = False
    If Left$(p, 9) = "forcefull" Then ThisWorkbook.ForceFullCalculation = True
    If p = "group-sheet" Then
        Set other = ThisWorkbook.Worksheets.Add(After:=ws)
        other.Name = "Grouped"
        other.Range("A1").Formula2 = "=PlainProbe(35,S!A1)"
        Application.Calculate
        ThisWorkbook.Worksheets(Array("S", "Grouped")).Select
    End If
    Stage "dirty-input"
    If Not other Is Nothing And Left$(p, 5) = "cross" Then
        other.Range("A1").Value2 = 5
    ElseIf Left$(p, 7) = "reverse" Then
        ws.Range("C1").Value2 = 5
    Else
        ws.Range("A1").Value2 = 5
    End If
    ws.Range("X1").Value2 = 1
    Snap ws, "A1:C1,B3:C3,K1,Y1"
    CountSnapshot
    Stage "tested-command"
    If Left$(p, 7) = "reverse" Then
        If op = "range" Then ws.Range("A1:B1").Calculate Else ws.Range("A1:B1").CalculateRowMajorOrder
    ElseIf InStr(p, "union-cb") > 0 Then
        Application.Union(c, b, ws.Range("C3"), ws.Range("B3")).Calculate
    ElseIf InStr(p, "union-bc") > 0 Then
        Application.Union(b, c, ws.Range("B3"), ws.Range("C3")).Calculate
    Else
        Select Case op
        Case "c1": c.Calculate: ws.Range("C3").Calculate
        Case "range": ws.Range("B1:C1,B3:C3").Calculate
        Case "sequential": b.Calculate: ws.Range("B3").Calculate: c.Calculate: ws.Range("C3").Calculate
        Case "sheet": ws.Calculate
        Case "app": Application.Calculate
        Case "full": Application.CalculateFull
        Case "rebuild": Application.CalculateFullRebuild
        Case "rowmajor": ws.Range("B1:C1,B3:C3").CalculateRowMajorOrder
        End Select
    End If
    Stage "after-command"
    Snap ws, "A1:C1,B3:C3,K1,Y1"
    If Left$(p, 5) = "cross" Then Snap other, "A1:B1"
    CountSnapshot
    Stage "followup-f9"
    Application.Calculate
    Snap ws, "A1:C1,B3:C3,K1,Y1"
    CountSnapshot
    Stage "followup-full"
    Application.CalculateFull
    Snap ws, "A1:C1,B3:C3,K1,Y1"
    CountSnapshot
    If Not provider Is Nothing Then provider.Close False
    Application.Calculation = xlCalculationManual
End Sub

