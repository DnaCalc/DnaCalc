Option Explicit
Private trace() As String
Private used As Long
Private calls(0 To 100) As Long
Private currentStage As String
Private currentCase As String
Private observedSheet As Worksheet
Private eventSink As Object
Public editOnSave As Boolean
Private loggerReady As Boolean
Private Type DoubleBox
    value As Double
End Type
Private Type ByteBox
    value(0 To 7) As Byte
End Type

Private Declare PtrSafe Function DumpNative Lib "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P07\native-async.xll" (ByVal path As LongPtr) As Long
Private Declare PtrSafe Function ResetNative Lib "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P07\native-async.xll" () As Long
Private Declare PtrSafe Function MarkNative Lib "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P07\native-async.xll" (ByVal stageNumber As Long) As Long
Private Declare PtrSafe Function ReleaseAfter Lib "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P07\native-async.xll" (ByVal milliseconds As Long) As Long
Private Declare PtrSafe Function ReleaseLatchAfter Lib "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P07\native-async.xll" (ByVal latch As Long, ByVal milliseconds As Long) As Long
Private Declare PtrSafe Function ReleaseCalls Lib "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P07\native-async.xll" (ByVal newestFirst As Long) As Long
Private Declare PtrSafe Function PendingAsync Lib "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P07\native-async.xll" () As Long
Private Declare PtrSafe Function UnregisterAsync Lib "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P07\native-async.xll" () As Long
Private Declare PtrSafe Function RegisterAsync Lib "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P07\native-async.xll" () As Long
Private Declare PtrSafe Function GetCurrentProcessId Lib "kernel32" () As Long
Private Declare PtrSafe Sub Sleep Lib "kernel32" (ByVal milliseconds As Long)
Private directOwner As Workbook
Private directTarget As String
Private directOutput As String
Private directControl As String

Public Sub Note(ByVal kind As String, ByVal detail As String)
    If Not loggerReady Then
        ReDim trace(0 To 200000)
        loggerReady = True
    End If
    If used > UBound(trace) Then Err.Raise 5, , "Trace capacity exceeded"
    trace(used) = currentCase & vbTab & currentStage & vbTab & kind & vbTab & detail
    used = used + 1
End Sub
Private Function Bits(ByVal x As Double) As String
    Dim d As DoubleBox, b As ByteBox, i As Long, t As String
    d.value = x
    LSet b = d
    For i = 7 To 0 Step -1
        t = t & Right$("0" & Hex$(b.value(i)), 2)
    Next
    Bits = t
End Function
Public Function Typed(ByVal x As Variant) As String
    Dim t As String
    If IsObject(x) Then
        Typed = "vt=9;type=" & TypeName(x) & ";value=<Object>"
        Exit Function
    End If
    t = "vt=" & CStr(VarType(x)) & ";type=" & TypeName(x) & ";value="
    If IsError(x) Then
        t = t & CStr(x)
    ElseIf IsEmpty(x) Then
        t = t & "<Empty>"
    ElseIf IsNull(x) Then
        t = t & "<Null>"
    ElseIf IsArray(x) Then
        t = t & "<Array>"
    Else
        t = t & Replace(Replace(CStr(x), vbTab, "<TAB>"), vbLf, "<LF>")
        If VarType(x) = vbDouble Then t = t & ";bits=" & Bits(CDbl(x))
    End If
    Typed = t
End Function
Public Sub Stage(ByVal label As String)
    currentStage = label
    Note "stage", label
End Sub
Public Sub Snap(ws As Worksheet, ByVal addresses As String)
    Dim a As Variant, r As Range, v As Variant
    For Each a In Split(addresses, ",")
        Set r = ws.Range(CStr(a))
        For Each r In r.Cells
            v = r.Value2
            Note "cell", ws.Name & "!" & r.Address(False, False) & ";" & Typed(v)
        Next
    Next
End Sub
Public Sub CountSnapshot()
    Dim i As Long
    For i = 0 To UBound(calls)
        If calls(i) > 0 Then Note "counter", CStr(i) & "=" & CStr(calls(i))
    Next
End Sub
Public Function PlainProbe(ByVal ident As Long, x As Variant) As Variant
    calls(ident) = calls(ident) + 1
    Note "entry", "PlainProbe;id=" & CStr(ident) & ";n=" & CStr(calls(ident)) & ";arg=" & Typed(x) & ";caller=" & Application.Caller.Address(External:=True)
    PlainProbe = x
    Note "exit", "PlainProbe;id=" & CStr(ident)
End Function
Public Function PeekB1() As Variant
    Dim v As Variant
    calls(1) = calls(1) + 1
    v = observedSheet.Range("B1").Value2
    Note "entry", "PeekB1;n=" & CStr(calls(1)) & ";caller=" & Application.Caller.Address(External:=True) & ";read=" & Typed(v)
    PeekB1 = v
    Note "exit", "PeekB1"
End Function
Public Function PeekSelf() As Variant
    Dim v As Variant
    v = Application.Caller.Value2
    Note "entry", "PeekSelf;read=" & Typed(v)
    PeekSelf = v
    Note "exit", "PeekSelf"
End Function
Public Function PeekTwice() As Variant
    Dim a As Variant, b As Variant, s As Variant
    a = observedSheet.Range("B1").Value2
    Note "entry", "PeekTwice;first=" & Typed(a)
    s = Application.WorksheetFunction.Sum(1)
    b = observedSheet.Range("B1").Value2
    Note "read", "PeekTwice;second=" & Typed(b) & ";sum=" & Typed(s)
    PeekTwice = b
    Note "exit", "PeekTwice"
End Function
Public Sub Profile()
    Note "profile", "version=" & Application.Version & ";build=" & Application.Build & ";calculationVersion=" & CStr(Application.CalculationVersion) & ";os=" & Application.OperatingSystem
    Note "settings", "mode=" & CStr(Application.Calculation) & ";iteration=" & CStr(Application.Iteration) & ";maxIterations=" & CStr(Application.MaxIterations) & ";maxChange=" & CStr(Application.MaxChange) & ";calculateBeforeSave=" & CStr(Application.CalculateBeforeSave) & ";events=" & CStr(Application.EnableEvents) & ";precisionAsDisplayed=" & CStr(ThisWorkbook.PrecisionAsDisplayed) & ";date1904=" & CStr(ThisWorkbook.Date1904) & ";mtc=" & CStr(Application.MultiThreadedCalculation.Enabled) & ";threads=" & CStr(Application.MultiThreadedCalculation.ThreadCount) & ";automationSecurity=" & CStr(Application.AutomationSecurity)
    Note "force-full-setting", CStr(ThisWorkbook.ForceFullCalculation)
    Dim a As Object
    For Each a In Application.AddIns
        Note "addin", a.Name & ";installed=" & CStr(a.Installed)
    Next
    On Error GoTo ComAddInsUnavailable
    For Each a In Application.COMAddIns
        Note "com-addin", a.progID & ";connected=" & CStr(a.Connect)
    Next
    Exit Sub
ComAddInsUnavailable:
    Note "profile-unavailable", "COMAddIns;error=" & CStr(Err.Number) & ";" & Err.Description
    Err.Clear
End Sub
Public Sub SpillInfo(ws As Worksheet, ByVal atCell As String)
    On Error GoTo NoSpill
    Dim r As Range, flag As Variant
    Set r = ws.Range(atCell)
    flag = r.HasSpill
    Note "spill-flag", atCell & ";" & Typed(flag)
    If IsNull(flag) Then Exit Sub
    If Not CBool(flag) Then Exit Sub
    Note "spill", atCell & ";hasSpill=True;range=" & r.SpillingToRange.Address
    Exit Sub
NoSpill:
    Note "spill", atCell & ";error=" & CStr(Err.Number) & ";" & Err.Description
    Err.Clear
End Sub
Public Function RunCase(ByVal ident As String, ByVal output As String) As String
    On Error GoTo Failed
    currentCase = ident
    ReDim trace(0 To 200000)
    loggerReady = True
    used = 0
    '__START_EVENT_SINK__
    If Not eventSink Is Nothing Then Set eventSink.XL = Application
    Application.Calculation = xlCalculationManual
    Application.CalculateBeforeSave = False
    Set observedSheet = ThisWorkbook.Worksheets(1)
    observedSheet.Name = "S"
    Stage "profile"
    Profile
    ProbeCase ident, output
    Stage "artifact-save"
    ThisWorkbook.SaveAs output, xlOpenXMLWorkbookMacroEnabled
    CountSnapshot
    Note "artifact", output
    GoTo Finished
Failed:
    Note "fault", CStr(Err.Number) & ";" & Err.Description
Finished:
    If used = 0 Then
        RunCase = "no observations"
    Else
        Dim resultLines() As String, k As Long
        ReDim resultLines(0 To used - 1)
        For k = 0 To used - 1
            resultLines(k) = trace(k)
        Next
        RunCase = Join(resultLines, vbLf)
    End If
End Function
Public Function ReadAfterOpen() As String
    currentCase = "reopened"
    Set observedSheet = ThisWorkbook.Worksheets(1)
    Stage "after-open"
    Snap observedSheet, "A1:C5,E1,E3:E8,G1:H3"
    Profile
    CountSnapshot
    Dim resultLines() As String, k As Long
    ReDim resultLines(0 To used - 1)
    For k = 0 To used - 1
        resultLines(k) = trace(k)
    Next
    ReadAfterOpen = Join(resultLines, vbLf)
End Function
Public Function RunProbe() As String
    On Error GoTo Failed
    If "1" = "1" Then
        RunProbe = "direct-command supervisor ready"
        Exit Function
    End If
    Dim i As Long, ident As Variant, wb As Workbook, component As Object, src As String, result As String, all As String, output As String, n As Long
    Application.Calculation = xlCalculationManual
    Application.CalculateBeforeSave = False
    Application.EnableEvents = True
    src = ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.Lines(1, ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.CountOfLines)
    For i = 1 To 1
        For Each ident In Split(SelectedCaseIds(), "|")
            Set wb = Application.Workbooks.Add(xlWBATWorksheet)
            wb.VBProject.VBComponents("ThisWorkbook").CodeModule.AddFromString EventSource()
            Set component = wb.VBProject.VBComponents.Add(2)
            component.Name = "ProbeEvents"
            component.CodeModule.AddFromString "Public WithEvents XL As Application" & vbCrLf & "Private Sub XL_AfterCalculate()" & vbCrLf & "OracleProbe.Note ""event"", ""AfterCalculate""" & vbCrLf & "End Sub"
            Set component = wb.VBProject.VBComponents.Add(1)
            component.Name = "OracleProbe"
            component.CodeModule.AddFromString Replace(src, "'__START_EVENT_SINK__", "Set eventSink = New ProbeEvents")
            output = "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P07\direct3-" & CStr(ident) & "-" & Format$(i, "00") & ".xlsm"
            result = Application.Run("'" & wb.Name & "'!OracleProbe.RunCase", CStr(ident) & "/" & CStr(i), output)
            all = all & result & vbLf
            wb.Close False
            Set wb = Nothing
        Next
    Next
    RunProbe = all
    Exit Function
Failed:
    RunProbe = all & vbLf & "driver-fault:" & CStr(Err.Number) & ":" & Err.Description
End Function
Public Function CreateOneCase(ByVal ident As String, ByVal output As String) As String
    Dim wb As Workbook, component As Object, src As String, ignored As String
    src = ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.Lines(1, ThisWorkbook.VBProject.VBComponents("OracleProbe").CodeModule.CountOfLines)
    Set wb = Application.Workbooks.Add(xlWBATWorksheet)
    wb.VBProject.VBComponents("ThisWorkbook").CodeModule.AddFromString EventSource()
    Set component = wb.VBProject.VBComponents.Add(2)
    component.Name = "ProbeEvents"
    component.CodeModule.AddFromString "Public WithEvents XL As Application" & vbCrLf & "Private Sub XL_AfterCalculate()" & vbCrLf & "OracleProbe.Note ""event"", ""AfterCalculate""" & vbCrLf & "End Sub"
    Set component = wb.VBProject.VBComponents.Add(1)
    component.Name = "OracleProbe"
    component.CodeModule.AddFromString Replace(src, "'__START_EVENT_SINK__", "Set eventSink = New ProbeEvents")
    ignored = Application.Run("'" & wb.Name & "'!OracleProbe.RunCase", ident, output)
    CreateOneCase = wb.Name
End Function
Private Function SelectedCaseIds() As String
    SelectedCaseIds = ""
    SelectedCaseIds = SelectedCaseIds & "normal|nested|overwrite"
    If Len(SelectedCaseIds) = 0 Then SelectedCaseIds = CaseIds()
End Function
Private Function EventSource() As String
    EventSource = "Option Explicit" & vbCrLf & _
        "Private Sub Workbook_SheetCalculate(ByVal Sh As Object)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""SheetCalculate;sheet="" & Sh.Name" & vbCrLf & _
        "End Sub" & vbCrLf & _
        "Private Sub Workbook_BeforeSave(ByVal SaveAsUI As Boolean, Cancel As Boolean)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""BeforeSave;saveAsUI="" & CStr(SaveAsUI)" & vbCrLf & _
        "If OracleProbe.editOnSave Then" & vbCrLf & _
        "OracleProbe.editOnSave = False" & vbCrLf & _
        "Me.Worksheets(""S"").Range(""A1"").Value2 = 7" & vbCrLf & _
        "OracleProbe.Note ""event"", ""BeforeSave-edited-A1=7""" & vbCrLf & _
        "End If" & vbCrLf & _
        "End Sub" & vbCrLf & _
        "Private Sub Workbook_AfterSave(ByVal Success As Boolean)" & vbCrLf & _
        "OracleProbe.Note ""event"", ""AfterSave;success="" & CStr(Success)" & vbCrLf & _
        "End Sub"
End Function

Private Function CaseIds() As String
    CaseIds = "normal|nested|overwrite|undo|arg-edit|move|close-reopen|duplicate|two-sites|supersede|reverse-release|reload|save-pending"
End Function
Public Function ReloadAsync() As String
    Dim status As Long
    status = UnregisterAsync()
    ReloadAsync = "unregister=" & CStr(status)
    If status = 0 Then ReloadAsync = ReloadAsync & ";register=" & CStr(RegisterAsync())
    Note "provider-reload", ReloadAsync
End Function
Private Sub WaitController(ByVal control As String)
    Dim start As Single
    start = Timer
    Do While Len(Dir$(control & ".done")) = 0 And Timer - start < 12
        DoEvents
        Sleep 10
    Loop
    Note "controller-done", CStr(Len(Dir$(control & ".done")) > 0)
End Sub
Private Sub ProbeCase(ByVal ident As String, ByVal output As String)
    Dim owner As Workbook, ws As Worksheet, wb As Workbook, p As String, op As String, formula As String
    Dim latch As Long, secondLatch As Long, n As Long, path As String, target As String, control As String, f As Integer, start As Single
    p = Split(ident, "/")(0)
    Stage "register-and-setup"
    Note "register-xll", CStr(Application.RegisterXLL("C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P07\native-async.xll"))
    n = ResetNative()
    Set owner = Application.Workbooks.Add(xlWBATWorksheet)
    Set ws = owner.Worksheets(1)
    ws.Name = "AsyncTarget"
    target = Replace(output, ".xlsm", "-target.xlsx")
    latch = CLng(Timer * 1000)
    ws.Range("A1").Value2 = 41
    ws.Range("B1").Value2 = latch
    formula = "=XBefore(1)+AsyncEcho(A1,B1)+XAfter(2)"
    If p = "nested" Then formula = "=XAfter(AsyncEcho(XBefore(A1),B1))"
    If p = "two-sites" Then formula = "=AsyncEcho(A1,B1)+AsyncEcho(A1+1,B1+1)"
    If p = "duplicate" Then ws.Range("B1").Value2 = -latch
    n = ReleaseAfter(250)
    ws.Range("C1").Formula2 = formula
    ws.Range("D1").Formula2 = "=C1+1"
    Stage "seed-calculation"
    n = ReleaseAfter(500)
    Application.Calculate
    start = Timer
    Do While Timer - start < 0.7
        DoEvents
        Sleep 10
    Loop
    Snap ws, "A1:D1"
    If IsError(ws.Range("C1").Value2) Then
        Note "unrunnable", "Async seed is an error; no pending-mutation inference"
        GoTo FinishCase
    End If
    owner.SaveAs target, xlOpenXMLWorkbook
    n = ResetNative()
    Stage "dirty-argument"
    ws.Range("A1").Value2 = 42
    latch = latch + 100
    ws.Range("B1").Value2 = latch
    If p = "duplicate" Then ws.Range("B1").Value2 = -latch
    secondLatch = 0
    If p = "two-sites" Or p = "reverse-release" Then secondLatch = latch + 1
    op = p
    If p = "nested" Or p = "duplicate" Or p = "two-sites" Then op = "normal"
    control = "C:\Work\DnaCalc\DnaCalc-cfml\crates\calc-engine\tests\fixtures\excel-calc-probes\P07\external-control-P07-direct-trial3-safe-" & CStr(GetCurrentProcessId()) & "-" & CStr(latch) & ".txt"
    f = FreeFile
    Open control For Output As #f
    Print #f, CStr(GetCurrentProcessId()) & vbTab & owner.Name & vbTab & op & vbTab & CStr(latch) & vbTab & CStr(secondLatch) & vbTab & target & vbTab & ThisWorkbook.Name
    Close #f
    n = ReleaseLatchAfter(latch, 5000)
    If secondLatch <> 0 Then n = ReleaseLatchAfter(secondLatch, 5000)
    If "1" = "1" Then
        Set directOwner = owner
        directTarget = target
        directOutput = output
        directControl = control
        Note "prepared-direct-command", owner.Name
        Exit Sub
    End If
    Stage "tested-calculation"
    n = MarkNative(1)
    start = Timer
    On Error GoTo CalculationReturnedError
    ws.Range("C1").Calculate
    Note "calculation-return", "duration-seconds=" & CStr(Timer - start) & ";state=" & CStr(Application.CalculationState)
    GoTo AwaitController
CalculationReturnedError:
    Note "calculation-error", CStr(Err.Number) & ";" & Err.Description & ";duration-seconds=" & CStr(Timer - start)
    Err.Clear
    Resume AwaitController
AwaitController:
    On Error GoTo 0
    Stage "await-external-controller"
    WaitController control
    start = Timer
    Do While Timer - start < 0.3
        DoEvents
        Sleep 10
    Loop
FinishCase:
    n = ReleaseCalls(0)
    start = Timer
    Do While PendingAsync() > 0 And Timer - start < 10
        DoEvents
        Sleep 10
    Loop
    Note "pending-native-callbacks", CStr(PendingAsync())
    If PendingAsync() > 0 Then Note "unrunnable", "Native callbacks have not drained; native tail is incomplete"
    Stage "after"
    For Each wb In Application.Workbooks
        If wb.FullName = target Or wb Is owner Then
            Snap wb.Worksheets(1), "A1:F1"
            Note "calculation-state", CStr(Application.CalculationState)
            Application.CalculateBeforeSave = False
            wb.SaveCopyAs Replace(output, ".xlsm", "-after.xlsx")
            Exit For
        End If
    Next
    path = Replace(output, ".xlsm", "-native.tsv")
    n = DumpNative(StrPtr(path))
    Note "native-records", CStr(n)
    On Error Resume Next
    For Each wb In Application.Workbooks
        If wb.FullName = target Or wb Is owner Then wb.Close False
    Next
    On Error GoTo 0
End Sub
Public Function CompleteDirectCase() As String
    Dim start As Single, n As Long, wb As Workbook, path As String
    Stage "direct-com-returned"
    WaitController directControl
    n = ReleaseCalls(0)
    start = Timer
    Do While PendingAsync() > 0 And Timer - start < 10
        DoEvents
        Sleep 10
    Loop
    Note "pending-native-callbacks", CStr(PendingAsync())
    If PendingAsync() > 0 Then Note "unrunnable", "Native callbacks did not drain"
    Stage "after"
    For Each wb In Application.Workbooks
        If wb.FullName = directTarget Or wb Is directOwner Then
            Snap wb.Worksheets(1), "A1:F1"
            Note "calculation-state", CStr(Application.CalculationState)
            wb.SaveCopyAs Replace(directOutput, ".xlsm", "-after.xlsx")
            Exit For
        End If
    Next
    path = Replace(directOutput, ".xlsm", "-native.tsv")
    n = DumpNative(StrPtr(path))
    Note "native-records", CStr(n)
    On Error Resume Next
    For Each wb In Application.Workbooks
        If wb.FullName = directTarget Or wb Is directOwner Then wb.Close False
    Next
    On Error GoTo 0
    CompleteDirectCase = ReadAfterOpen()
End Function
Public Function BeginDirectCase() As String
    Dim n As Long
    Stage "tested-direct-com"
    n = MarkNative(1)
    BeginDirectCase = "begin-direct"
End Function
Public Function DirectControlPath() As String
    DirectControlPath = directControl
End Function

