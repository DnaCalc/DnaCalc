# DNA Calc · Pro 20 mockups

All ten requested HTML deliverables are included, with **43 unique scenes**, every accepted **S01–S16** and **F01–F07** ID, and three to six callouts per scene.

## Quick start

1. Extract the entire ZIP into one folder.
2. Open **index.html** in a desktop browser. No installation, server or internet connection is needed for the mockups.
3. Choose a thumbnail or open **storyboards.html** for the seven stories in order.
4. Use the review bar to select a scene, step Previous/Next, compare the normal/story state with its exception variant, or enable 200% zoom, high contrast and reduced motion. Left/right arrows step when focus is outside an interactive control.

Product navigation within an opened mockup preserves the shared model and the implemented source/undo flows in that document. Reloading, opening a different HTML file directly, or following a gallery link starts a new session. Direct entry into a storyboard can initialise that story moment. No workbook edits or recordings are saved to disk.

## Package contents

| File | Contents |
|---|---|
| index.html | Gallery of all 43 scenes |
| design-system.html | Strand tokens, type, cell states, drawers, ports and wires |
| classic.html | F01 and seven keyboard/mouse gesture scenes |
| storyboards.html | S01–S16, in story order |
| inspector.html | Result explanation, Stock instruments and scripted RTD feeds |
| notebook.html | Bound narrative, 25,000-order data frame and sheet pipeline |
| model-map.html | Period model, hierarchy and ticked state model |
| app.html | Loan live/batched/invalid inputs, print proof and Stock clock controls |
| formula-explorer.html | Docked/standalone tests, expected errors and caller refusal |
| agent.html | Select, preview, apply, undo and resolve stale proposals |
| verification.html | Full scene register, exact fixture checkpoints, checks, limits and sources |
| README.md | This quick start |

The HTML files embed their CSS, JavaScript and SVG. There are no external assets, CDNs or web-font downloads. Keep the files together for gallery and report links.

## Useful routes to try

- **Classic C01–C07:** key tips, reference picking, F4 anchors, fill, Ctrl+Enter, move and command search. Visible buttons are available if the host captures a shortcut.
- **App F05 / A01 / A02:** edit the Loan live; compare batching; run or step the shared Stock clock.
- **Inspector I03 → Map M02 → App A02:** follow the same ticked state through three views.
- **Explorer F06:** trial 20% while the source remains at 10%, Apply, reveal Summary!D14 in Classic, then Undo.
- **Agent S14:** select A+B, review, apply, then undo once. The heading reverts while price stays 125 and annual profit stays 276,000. S16 presents the stale-price conflict.

## Verification boundary

The construction checks passed **231 Work assertions**, **14 Classic scenario groups**, **11 Storyboard scenario groups** and **35 Inspector/Notebook/Map checks**, plus structural checks for all 43 scenes. These counts measure different things and are not combined into a single test total.

The final gallery/navigation check passed all **48 thumbnail targets**, covering **43 unique scenes**, with nine scenario groups for keyboard stepping, variant controls, workbook continuity and source navigation.

Validation used **jsdom and offline WeasyPrint proofs**. Native browser launch was blocked and the connected Browser was unavailable. Native layout, OS shortcut interception, screen-reader conformance, clipboard permissions, print dialogs and physical/PDF output were not validated. No actual Excel, XLL, RTD server, VBA macro or external feed executed. QA tooling is not included separately in this 12-file review ZIP.

The ticked Stock model uses an explicit immutable previous-state snapshot for each accepted demo tick. An RTD formula, self-reference and one-iteration setting alone do not establish that execution contract in Excel. Insufficient evidence is labelled **Unknown**. The reserve starts at its fixed point 20; it is not a separate 100-iteration solver inside a one-iteration model.

Read **verification.html** for the exact arithmetic, full interaction coverage and primary Microsoft documentation.
