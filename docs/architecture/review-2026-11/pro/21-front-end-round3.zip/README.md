# DNA Calc · Pro 21 front end, round 3

The Pro 20 package is extended to **73 unique scenes**: **all 43 originals retained plus 30 additions**. There are **13 self-contained mockup HTML files**, this verification report and this README: **15 ZIP members**.

The main addition is a computation notebook. Its visible written formula is followed immediately by its result, then the next formula and result. Prose sits between these links. Author, Read and Across are presentations of the same underlying cells.

## Quick start

1. Extract the entire ZIP into one folder.
2. Open **index.html** in a desktop browser. No server, installation or internet connection is needed.
3. Start with **notebook-compute.html**, scene **NC01**. Change Status to Paid, follow a named reference, show Backing cells and switch Read/Across.
4. Use the review bar to change scenes, compare normal/exception variants, and inspect 200% zoom, high contrast or reduced motion. Left/right arrows step when focus is outside an interactive control.

Every scene has three to six callouts beside its 1440 × 900 product frame. Product navigation within an open document retains shared state. Gallery links, a different file or a reload start a new session. Direct storyboard entry can initialise its named story moment.

## Computation notebook route

| Scene | What to try |
|---|---|
| NC01 | FILTER → GROUPBY/PIVOTBY → SORTBY → chart → LET total, with visible formulas and outputs |
| NC02 | Edit the FILTER, use completion/signature help, rename its output and follow a downstream reference |
| NC03 | Change status, region and dates; all downstream tables, chart and prose respond immediately |
| NC04 | Expand LET bindings; observe the shared Report!E2 price and its 40-unit valuation |
| NC05 | Inspect MarginPct as a workbook LAMBDA; change Budget inputs and inspect its callers |
| NC06 | West/Pending fits; change Region to All to block the spill at A16, review relocation, then Undo |
| NC07 | Read the same Sales cells as a write-up and open its print preview |

NC06 is an explicit alternate backing-layout scenario. It does not add an obstruction to the ordinary Sales notebook. Incomplete/unsupported source drafts withhold dependent results until a complete supported expression is restored; Esc restores the committed formula. The local evaluator supports the displayed linked FILTER and literal Pending/Paid FILTER forms, not arbitrary Excel formulas.

## Other new scenes

| Area | Scenes | Contents |
|---|---|---|
| Workbook patterns and views | W01–W05 | Inherited structure; Budget why/confirm/correct/invalidate; Orders database; mixed views; file preferences and fallback |
| Customisation | U01–U05 | Layout declaration/live preview; contrast; keymap; agent dark Classic; three-line Loan App proposal/binding review |
| File and print | O01–O04 | Open/recent/pattern; Save; Notebook print; selected Model map region print |
| Model map scale | M03–M05 | 40-sheet group map, counts, expand-all refusal, blocks and optional sheet page |
| Guarded macros | G01–G03 | Trust and captured action plan; view/selection operation; refusal before action |
| Formula Explorer | E01–E03 | Standalone function browser and live tree; formatting; sample XLL/XLAM library |

## Files

| File | Contents |
|---|---|
| index.html | All 73 scenes in a thumbnail gallery; the computation notebook is the first collection. |
| notebook-compute.html | Seven formula-first computation scenes: author, edit, reactive controls, live tree/price, LAMBDA, backing cells, report. |
| workbook.html | Pattern recognition, mixed views, file preferences, File/Open/Save, Notebook and Map print previews. |
| customise.html | Layout declaration, tokens, keymap, agent dark Classic, Loan App review, Guarded macro demonstrations. |
| design-system.html | Original Strand tokens, type, cell states, focus, selection, drawers, ports and wires. |
| classic.html | Original reference editor and seven keyboard/mouse demonstrations. |
| storyboards.html | Every moment of the original seven stories, in order. |
| inspector.html | Sales contribution trace; Stock instruments, shared Sales price and ticked Live panel. |
| notebook.html | Original bound narrative, complete-scope data frame and cross-sheet pipeline. |
| model-map.html | Original period/ticked model plus bounded Inherited sheet groups, blocks and optional sheet page. |
| app.html | Original Loan live/batched/invalid states, complete print proof and Stock tick controls. |
| formula-explorer.html | Original docked/standalone trials plus function browser, live tree, formats and add-in library. |
| agent.html | Original review units, exact preview, atomic acceptance, separate Undo and stale conflict. |
| verification.html | Complete scene registry, workbook mapping, exact arithmetic, checks, fixes, limitations and primary sources |
| README.md | This quick start |


## Workbook mapping and exact checkpoints

Sales has a proposed visible **Analysis** sheet. Its raw spill is **A10:G…**; aggregates use separate lanes **J:K, M:N, Q:R and U:V**, so downward growth does not run into subsequent formulas. **B2:B6** hold region, status, inclusive first/last November days and held units. **J2** is the total; **Report!E2** is the live source; **J5** is its valuation. Named outputs refer to ordinary anchors or spill references. The chart is an ordinary proposed Excel chart object backed by named worksheet ranges. Budget's MarginPct is a workbook defined name containing LAMBDA, with ordinary callers at Analysis!B10:B14.

For all regions and November 1–28:

| Status | Rows | Amount |
|---|---:|---:|
| Pending | 4,147 | R4,667,700 |
| Paid | 20,853 | R23,440,150 |
| All | 25,000 | R28,107,850 |

Paid descending regional rank is South, East, North, West; South exceeds East by exactly R25. GROUPBY and the one-month PIVOTBY use exact aggregates of the entire fixture. A separate reference loop reconstructs expected counts/sums from the row specification, rather than calling the implementation to create its expectations. The full formulas, per-region totals, controls, names, spill/error behavior and chart mapping are in **verification.html**.

The view declaration proposes namespace **urn:dnacalc:views:v1** and an optional custom-XML part. The actual free part name must be allocated by a production writer. Prose and presentation live there; worksheets/formulas/names remain the ordinary-reader fallback. The checked declaration round trip is JSON serialization, not a native Excel file round trip.

## State, Save and Print

Save captures a local in-memory model/view snapshot. It does not write an XLSX/XLSM or save the complete review session. Export view settings offers JSON. Save keeps the current workbook, source filename and sheet declarations, includes accepted customisation, and refuses the illustrated macro-losing format choice.

Print previews capture the current model and remain frozen until Refresh. Notebook requests A4 portrait and Model map requests A4 landscape. The original complete Loan print proof is retained. Actual print dialogs, browser pagination and physical/PDF output were not tested.

## Verification

The original regression checks pass: **231 Work assertions**, **14 Classic scenario groups**, **11 Storyboard scenario groups**, and **35 Inspector/Notebook/Map checks**.

New focused checks pass: **29 Notebook checks**, **146 customisation/Guarded assertions in 17 groups**, **32 workbook/scale/clock checks**, **30 File/Save/Print checks**, and **25 expanded Explorer checks**.

The final gallery check opens **78 thumbnail targets covering 73 unique scenes**, with **9 navigation scenario groups**. Structural checks retain all original 43 IDs and report zero issues or missing form labels. **6 cross-module integration checks** cover current Notebook backing, File context, the shared RTD source, observer cleanup and preview/snapshot purity. **8 conversation-preview checks** pass.

These are different units and are not combined into one test total. All 30 new scenes received offline full-size visual proof review; final geometry fixes were re-rendered. Package audit checks embedded assets, zero external resource requirements and ZIP integrity.

## What remains unverified

- Native Browser access was unavailable and native browser launch was blocked. Validation used **jsdom and offline WeasyPrint proofs**, not native browser certification.
- No actual Excel evaluation, XLSX/XLSM writer, custom-XML retention, VBA/XLL execution, COM RTD provider or external feed was run.
- Guarded macros are finite declared local action plans, not an arbitrary-code sandbox or general VBA preflight guarantee. Off / Guarded / Unguarded are the exact proposed levels.
- Explorer match counts/worst-ulp values are clearly labelled sample archive records. They are not measured corpus results.
- Inherited's 40 sheets, 300,000 formula members, 6 hidden sheets, 90 relationships and 85,272 reference records are deterministic manifest evidence, not a native scan or performance measurement.
- OS keyboard interception, clipboard permissions, screen-reader behavior, WCAG conformance and real print/download interfaces were not certified.

The ticked Stock model reads one immutable previous-state snapshot per accepted demo tick. RTD, self-reference and a one-iteration setting alone do not prove that contract in Excel. Unknown evidence remains labelled Unknown; the reserve starts at its fixed point 20 and is not an independent 100-iteration solver.

**verification.html** preserves the original fixture/clock detail and lists every scene, correction and source. All mockup assets are inline; there are no CDNs, web-font requests or Microsoft artwork.
